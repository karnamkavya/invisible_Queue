import React, { useState } from 'react';
import { BenchmarkMetrics } from '../types';
import { BenchmarkRunner } from '../evaluation/benchmark';
import { 
  FlaskConical, 
  X, 
  Play, 
  CheckCircle, 
  AlertCircle, 
  Activity, 
  Layers, 
  ShieldCheck, 
  RotateCcw 
} from 'lucide-react';

interface EvaluationModalProps {
  isOpen: boolean;
  onClose: () => void;
  metrics: BenchmarkMetrics;
  onUpdateMetrics: (metrics: BenchmarkMetrics) => void;
  runner: BenchmarkRunner;
}

export const EvaluationModal: React.FC<EvaluationModalProps> = ({
  isOpen,
  onClose,
  metrics,
  onUpdateMetrics,
  runner,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState<string>('');
  const [progress, setProgress] = useState(0);

  if (!isOpen) return null;

  const handleRunBenchmark = async () => {
    setIsRunning(true);
    setProgress(0);
    try {
      const results = await runner.runEvaluationBenchmark((step, pct) => {
        setCurrentStep(step);
        setProgress(pct);
      });
      onUpdateMetrics(results);
    } finally {
      setIsRunning(false);
    }
  };

  const handleReset = () => {
    runner.reset();
    onUpdateMetrics(runner.getMetrics());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-500/20 border border-purple-500/40 flex items-center justify-center">
              <FlaskConical className="w-4 h-4 text-purple-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                System Evaluation & Benchmark Panel
              </h2>
              <p className="text-xs text-slate-400">
                Ground-truth accuracy, stability, and latency measurements
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Status Banner */}
          {!metrics.isEvaluated && !isRunning ? (
            <div className="bg-amber-950/40 border border-amber-800/80 rounded-xl p-5 text-center flex flex-col items-center justify-center">
              <AlertCircle className="w-8 h-8 text-amber-400 mb-2" />
              <div className="text-sm font-black text-amber-300 tracking-wide uppercase">
                NOT EVALUATED YET
              </div>
              <p className="text-xs text-slate-400 max-w-md mt-1 mb-4 leading-relaxed">
                Project honesty protocol: Benchmark metrics are strictly withheld until an automated ground-truth evaluation is performed. No fabricated or assumed metrics are displayed.
              </p>
              <button
                onClick={handleRunBenchmark}
                className="bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-5 py-2.5 rounded-lg flex items-center gap-2 shadow-lg shadow-purple-600/30 cursor-pointer transition-all"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Run Automated Ground-Truth Benchmark</span>
              </button>
            </div>
          ) : isRunning ? (
            <div className="bg-slate-800/70 border border-purple-800/80 rounded-xl p-6 text-center space-y-3">
              <div className="text-sm font-bold text-purple-300 uppercase tracking-wide">
                Running Verification Benchmark
              </div>
              <p className="text-xs text-slate-300 font-mono">{currentStep}</p>
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-400">{progress}% complete</span>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Evaluated Header Badge */}
              <div className="bg-emerald-950/50 border border-emerald-800/80 rounded-xl p-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <div>
                    <div className="text-xs font-bold text-emerald-300">
                      Benchmark Completed & Verified
                    </div>
                    <div className="text-[10px] text-slate-400">
                      Evaluated on 3,600 annotated synthetic ground-truth frames at {new Date(metrics.evaluatedAt!).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleReset}
                  className="text-slate-400 hover:text-slate-200 text-[11px] flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Status</span>
                </button>
              </div>

              {/* Metric Categories Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Detection Metrics */}
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span>Person Detection (IoU @ 0.5)</span>
                  </h3>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Precision:</span>
                      <span className="font-mono font-bold text-cyan-400 text-sm">
                        {(metrics.detectionPrecision * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Recall:</span>
                      <span className="font-mono font-bold text-cyan-400 text-sm">
                        {(metrics.detectionRecall * 100).toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* 2. Tracking Stability */}
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-purple-400" />
                    <span>Anonymous Multi-Person Tracking</span>
                  </h3>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">HOTA Tracking Stability:</span>
                      <span className="font-mono font-bold text-purple-400 text-sm">
                        {(metrics.trackingStabilityHOTA * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">ID Switch Frequency:</span>
                      <span className="font-mono font-bold text-purple-400 text-sm">
                        {metrics.idSwitchRatePerMin} / min
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. Performance & Latency */}
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-emerald-400" />
                    <span>Edge Processing Performance</span>
                  </h3>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Processing Latency:</span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        {metrics.processingLatencyMs} ms / frame
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Average Throughput:</span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        {metrics.averageFPS} FPS
                      </span>
                    </div>
                  </div>
                </div>

                {/* 4. Congestion & Prediction Accuracy */}
                <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-amber-400" />
                    <span>Congestion Classification & Prediction</span>
                  </h3>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Congestion State Accuracy:</span>
                      <span className="font-mono font-bold text-amber-400 text-sm">
                        {(metrics.congestionClassificationAccuracy * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">False Alert Rate:</span>
                      <span className="font-mono font-bold text-amber-400 text-sm">
                        {metrics.falseAlertRatePercent}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">60s Prediction RMSE:</span>
                      <span className="font-mono font-bold text-amber-400 text-sm">
                        {metrics.predictionRMSE_60s}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
