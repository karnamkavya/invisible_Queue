import React, { useState } from 'react';
import { AutomatedTestSuite, TestCaseResult } from '../tests/testSuite';
import { CheckCircle2, XCircle, Play, RotateCcw, X, ShieldCheck } from 'lucide-react';

interface TestRunnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TestRunnerModal: React.FC<TestRunnerModalProps> = ({ isOpen, onClose }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [testResults, setTestResults] = useState<{
    passedCount: number;
    failedCount: number;
    totalCount: number;
    results: TestCaseResult[];
  } | null>(null);

  if (!isOpen) return null;

  const handleRunTests = async () => {
    setIsRunning(true);
    try {
      const results = await AutomatedTestSuite.runAllTests();
      setTestResults(results);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                Automated Verification Test Suite
              </h2>
              <p className="text-xs text-slate-400">
                In-app regression unit tests for all core algorithms
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {!testResults && !isRunning && (
            <div className="text-center p-8 bg-slate-800/50 rounded-xl border border-slate-750">
              <p className="text-slate-300 text-xs mb-4">
                Execute automated validation tests across all algorithms: Person counting, anonymous IDs, point-in-polygon zoning, density calibration, multi-signal congestion scoring, prediction uncertainty bounds, and anomaly neutral phrasing.
              </p>
              <button
                onClick={handleRunTests}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-5 py-2.5 rounded-lg flex items-center gap-2 shadow-lg shadow-emerald-600/30 mx-auto cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Run Automated Test Suite (10 Tests)</span>
              </button>
            </div>
          )}

          {isRunning && (
            <div className="text-center p-8 bg-slate-800/50 rounded-xl border border-slate-750 space-y-2">
              <div className="w-8 h-8 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin mx-auto" />
              <div className="text-sm font-bold text-slate-200">Running Unit Test Matrix...</div>
              <div className="text-xs text-slate-400">Testing mathematical functions and tracker stability</div>
            </div>
          )}

          {testResults && !isRunning && (
            <div className="space-y-4">
              {/* Summary Bar */}
              <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="text-xs">
                    Tests Run: <strong className="text-slate-100">{testResults.totalCount}</strong>
                  </div>
                  <div className="text-xs text-emerald-400 font-bold">
                    Passed: {testResults.passedCount}
                  </div>
                  {testResults.failedCount > 0 && (
                    <div className="text-xs text-rose-400 font-bold">
                      Failed: {testResults.failedCount}
                    </div>
                  )}
                </div>
                <button
                  onClick={handleRunTests}
                  className="text-xs text-slate-300 hover:text-white bg-slate-700 px-3 py-1 rounded flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Rerun</span>
                </button>
              </div>

              {/* Individual Test Cards */}
              <div className="space-y-2">
                {testResults.results.map((t, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-lg border text-xs flex items-start justify-between gap-3 ${
                      t.passed
                        ? 'bg-slate-800/60 border-slate-700/80 text-slate-200'
                        : 'bg-rose-950/40 border-rose-800 text-rose-200'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      {t.passed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="font-bold flex items-center gap-2">
                          <span>{t.name}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-400">
                            {t.category}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                          {t.message}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500 whitespace-nowrap">
                      {t.durationMs}ms
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
