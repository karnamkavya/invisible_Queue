import { BoundingBox, Detection, Point } from '../types';

export interface FrameAnalysisResult {
  detections: Detection[];
  luminance: number; // 0 - 255
  isLowLight: boolean;
  isCameraShaking: boolean;
  shakeMagnitude: number;
}

export class PersonDetector {
  private prevFrameData: Uint8ClampedArray | null = null;
  private prevCentroid: Point | null = null;
  private width: number = 640;
  private height: number = 360;
  private lowLightThreshold: number = 50;
  private minDetectionConfidence: number = 0.4;

  constructor(width: number = 640, height: number = 360) {
    this.width = width;
    this.height = height;
  }

  public setDimensions(width: number, height: number): void {
    this.width = width;
    this.height = height;
  }

  /**
   * Analyzes an HTML canvas or image frame to detect moving pedestrians,
   * measure luminance, and estimate camera shake.
   */
  public analyzeCanvasFrame(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number
  ): FrameAnalysisResult {
    this.width = width;
    this.height = height;

    try {
      const imgData = ctx.getImageData(0, 0, width, height);
      const data = imgData.data;
      const totalPixels = width * height;

      // 1. Calculate average luminance
      let totalLuminance = 0;
      // Sample every 4th pixel for performance
      for (let i = 0; i < data.length; i += 16) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        // Standard Rec. 709 luma formula
        const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        totalLuminance += luma;
      }
      const sampleCount = totalPixels / 4;
      const avgLuminance = totalLuminance / sampleCount;
      const isLowLight = avgLuminance < this.lowLightThreshold;

      // 2. Motion / Foreground difference
      let shakeMagnitude = 0;
      let isCameraShaking = false;
      const detections: Detection[] = [];

      if (this.prevFrameData && this.prevFrameData.length === data.length) {
        let diffSumX = 0;
        let diffSumY = 0;
        let diffCount = 0;

        // Downsampled grid for blob / person detection
        const gridW = 32;
        const gridH = 18;
        const cellW = width / gridW;
        const cellH = height / gridH;
        const gridHits = new Uint8Array(gridW * gridH);

        for (let gy = 0; gy < gridH; gy++) {
          for (let gx = 0; gx < gridW; gx++) {
            const px = Math.floor((gx + 0.5) * cellW);
            const py = Math.floor((gy + 0.5) * cellH);
            const idx = (py * width + px) * 4;

            const rDiff = Math.abs(data[idx] - this.prevFrameData[idx]);
            const gDiff = Math.abs(data[idx + 1] - this.prevFrameData[idx + 1]);
            const bDiff = Math.abs(data[idx + 2] - this.prevFrameData[idx + 2]);
            const diff = (rDiff + gDiff + bDiff) / 3;

            // Threshold for foreground motion
            if (diff > 22) {
              gridHits[gy * gridW + gx] = 1;
              diffSumX += px;
              diffSumY += py;
              diffCount++;
            }
          }
        }

        // Camera shake detection: if vast majority of grid cells moved simultaneously
        const globalMotionRatio = diffCount / (gridW * gridH);
        if (globalMotionRatio > 0.45) {
          isCameraShaking = true;
          shakeMagnitude = globalMotionRatio;
        }

        // Cluster motion blocks into person-sized bounding boxes
        const visited = new Uint8Array(gridW * gridH);
        let detCounter = 1;

        for (let gy = 0; gy < gridH; gy++) {
          for (let gx = 0; gx < gridW; gx++) {
            const gIdx = gy * gridW + gx;
            if (gridHits[gIdx] === 1 && visited[gIdx] === 0) {
              // BFS cluster
              let minGX = gx;
              let maxGX = gx;
              let minGY = gy;
              let maxGY = gy;
              let clusterCount = 0;

              const queue: [number, number][] = [[gx, gy]];
              visited[gIdx] = 1;

              while (queue.length > 0) {
                const [cx, cy] = queue.shift()!;
                clusterCount++;
                if (cx < minGX) minGX = cx;
                if (cx > maxGX) maxGX = cx;
                if (cy < minGY) minGY = cy;
                if (cy > maxGY) maxGY = cy;

                // 4-neighborhood
                const neighbors = [
                  [cx + 1, cy],
                  [cx - 1, cy],
                  [cx, cy + 1],
                  [cx, cy - 1],
                ];

                for (const [nx, ny] of neighbors) {
                  if (nx >= 0 && nx < gridW && ny >= 0 && ny < gridH) {
                    const nIdx = ny * gridW + nx;
                    if (gridHits[nIdx] === 1 && visited[nIdx] === 0) {
                      visited[nIdx] = 1;
                      queue.push([nx, ny]);
                    }
                  }
                }
              }

              // Filter out noise clusters or excessively giant global shifts
              if (clusterCount >= 2 && clusterCount <= 28) {
                const bx = minGX * cellW;
                const by = minGY * cellH;
                const bw = Math.max(30, (maxGX - minGX + 1) * cellW);
                const bh = Math.max(55, (maxGY - minGY + 1) * cellH);

                const aspectRatio = bh / (bw || 1);
                // Pedestrian aspect ratio usually between 1.4 and 3.2
                const isPedestrianShape = aspectRatio >= 1.2 && aspectRatio <= 3.8;
                const rawConfidence = isPedestrianShape ? 0.75 + Math.min(0.2, clusterCount * 0.02) : 0.45;
                const confidence = isLowLight ? rawConfidence * 0.78 : rawConfidence;

                if (confidence >= this.minDetectionConfidence) {
                  detections.push({
                    id: `det-${detCounter++}`,
                    bbox: { x: bx, y: by, width: bw, height: bh },
                    confidence: Number(confidence.toFixed(2)),
                    center: { x: bx + bw / 2, y: by + bh / 2 },
                    aspectRatio,
                  });
                }
              }
            }
          }
        }
      }

      // Keep copy of current frame for next comparison
      if (!this.prevFrameData || this.prevFrameData.length !== data.length) {
        this.prevFrameData = new Uint8ClampedArray(data.length);
      }
      this.prevFrameData.set(data);

      return {
        detections,
        luminance: Math.round(avgLuminance),
        isLowLight,
        isCameraShaking,
        shakeMagnitude,
      };
    } catch {
      // In case of cross-origin or canvas read errors
      return {
        detections: [],
        luminance: 128,
        isLowLight: false,
        isCameraShaking: false,
        shakeMagnitude: 0,
      };
    }
  }

  /**
   * Helper to create realistic detections from simulated synthetic agents.
   * Adds realistic sensor noise, confidence drop in low light or heavy overlap.
   */
  public generateDetectionsFromSyntheticAgents(
    agents: { x: number; y: number; width: number; height: number; active: boolean }[],
    options: { isLowLight?: boolean; cameraShake?: boolean; occlusionDrop?: boolean } = {}
  ): Detection[] {
    const detections: Detection[] = [];

    for (let i = 0; i < agents.length; i++) {
      const ag = agents[i];
      if (!ag.active) continue;

      // Jitter
      const jitterX = options.cameraShake ? (Math.random() - 0.5) * 8 : (Math.random() - 0.5) * 2;
      const jitterY = options.cameraShake ? (Math.random() - 0.5) * 8 : (Math.random() - 0.5) * 2;

      // Base confidence
      let confidence = 0.88 + Math.random() * 0.1;
      if (options.isLowLight) {
        confidence -= 0.35 + Math.random() * 0.15; // Realistic low light degradation
      }

      // Check overlap with other agents
      if (options.occlusionDrop) {
        let overlapCount = 0;
        for (let j = 0; j < agents.length; j++) {
          if (i !== j && agents[j].active) {
            const dist = Math.hypot(ag.x - agents[j].x, ag.y - agents[j].y);
            if (dist < 32) overlapCount++;
          }
        }
        if (overlapCount > 0) {
          confidence -= overlapCount * 0.12;
        }
      }

      // Low confidence filter: Never invent detections below threshold
      if (confidence < this.minDetectionConfidence) {
        continue;
      }

      const bw = ag.width;
      const bh = ag.height;
      const bx = ag.x - bw / 2 + jitterX;
      const by = ag.y - bh / 2 + jitterY;

      detections.push({
        id: `sim-det-${i + 1}`,
        bbox: { x: bx, y: by, width: bw, height: bh },
        confidence: Number(Math.min(0.99, Math.max(0.35, confidence)).toFixed(2)),
        center: { x: ag.x + jitterX, y: ag.y + jitterY },
        aspectRatio: bh / (bw || 1),
      });
    }

    return detections;
  }
}
