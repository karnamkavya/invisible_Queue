import { DemoScenarioType, Point, WhatIfScenarioState } from '../types';

export interface SyntheticAgent {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  vx: number;
  vy: number;
  targetX: number;
  targetY: number;
  speed: number;
  active: boolean;
  colorVariation: string;
  pathIndex: number;
  spawnTime: number;
}

export interface SyntheticSimulatorParams {
  agentCount: number;
  baseSpeed: number; // px/s
  entryRatePerMinute: number;
  pathwayCapacity: number;
  scenario: DemoScenarioType;
  entranceClosed: boolean;
  alternatePathOpen: boolean;
  zoneRestricted: boolean;
  incomingFlowMultiplier: number;
  isLowLight: boolean;
}

export const DEFAULT_SIM_PARAMS: SyntheticSimulatorParams = {
  agentCount: 22,
  baseSpeed: 38,
  entryRatePerMinute: 35,
  pathwayCapacity: 20,
  scenario: 'NORMAL_FLOW',
  entranceClosed: false,
  alternatePathOpen: false,
  zoneRestricted: false,
  incomingFlowMultiplier: 1.0,
  isLowLight: false,
};

export class SyntheticCrowdSimulator {
  private agents: SyntheticAgent[] = [];
  private width: number = 640;
  private height: number = 360;
  private nextAgentId = 1;
  private params: SyntheticSimulatorParams;
  private lastSpawnTime = 0;

  constructor(width: number = 640, height: number = 360, params: Partial<SyntheticSimulatorParams> = {}) {
    this.width = width;
    this.height = height;
    this.params = { ...DEFAULT_SIM_PARAMS, ...params };
    this.initAgents();
  }

  public setParams(newParams: Partial<SyntheticSimulatorParams>): void {
    this.params = { ...this.params, ...newParams };
    // Adjust agent count if drastically different
    if (this.agents.length < this.params.agentCount) {
      const diff = this.params.agentCount - this.agents.length;
      for (let i = 0; i < diff; i++) {
        this.spawnAgent();
      }
    } else if (this.agents.length > this.params.agentCount + 10) {
      this.agents = this.agents.slice(0, this.params.agentCount);
    }
  }

  public getParams(): SyntheticSimulatorParams {
    return this.params;
  }

  public setScenario(scenario: DemoScenarioType): void {
    this.params.scenario = scenario;
    switch (scenario) {
      case 'NORMAL_FLOW':
        this.params.agentCount = 18;
        this.params.baseSpeed = 36;
        this.params.entryRatePerMinute = 30;
        this.params.isLowLight = false;
        this.params.entranceClosed = false;
        this.params.zoneRestricted = false;
        this.params.alternatePathOpen = false;
        break;
      case 'GRADUAL_CONGESTION':
        this.params.agentCount = 38;
        this.params.baseSpeed = 22;
        this.params.entryRatePerMinute = 60;
        this.params.isLowLight = false;
        this.params.entranceClosed = false;
        this.params.zoneRestricted = false;
        break;
      case 'HIGH_CONGESTION':
        this.params.agentCount = 56;
        this.params.baseSpeed = 8;
        this.params.entryRatePerMinute = 85;
        this.params.isLowLight = false;
        this.params.entranceClosed = false;
        this.params.zoneRestricted = true;
        break;
      case 'SUDDEN_CROWD_MOVEMENT':
        this.params.agentCount = 28;
        this.params.baseSpeed = 52;
        this.params.isLowLight = false;
        // Trigger sudden heading reverse
        for (const ag of this.agents) {
          ag.targetX = ag.x < 320 ? 40 : 600;
          ag.vx = -ag.vx * 1.5;
        }
        break;
      case 'OVERLAPPING_PEOPLE':
        this.params.agentCount = 32;
        this.params.baseSpeed = 28;
        this.params.isLowLight = false;
        // Direct agents into central bottleneck
        for (const ag of this.agents) {
          ag.targetX = 250 + (Math.random() - 0.5) * 40;
          ag.targetY = 180 + (Math.random() - 0.5) * 40;
        }
        break;
      case 'LOW_LIGHT':
        this.params.agentCount = 16;
        this.params.baseSpeed = 30;
        this.params.isLowLight = true;
        break;
    }
  }

  private initAgents(): void {
    this.agents = [];
    for (let i = 0; i < this.params.agentCount; i++) {
      this.spawnAgent(true);
    }
  }

  private spawnAgent(randomInitialPos: boolean = false): void {
    const isEastbound = Math.random() > 0.15; // 85% normal directional flow
    const startX = randomInitialPos
      ? 40 + Math.random() * (this.width - 100)
      : isEastbound
      ? 25 + Math.random() * 40
      : this.width - 35 - Math.random() * 40;

    const startY = 80 + Math.random() * (this.height - 160);
    const targetX = isEastbound ? this.width - 25 : 30;
    const targetY = 80 + Math.random() * (this.height - 160);

    const colors = ['#64748b', '#475569', '#334155', '#1e293b', '#0f172a'];
    const color = colors[Math.floor(Math.random() * colors.length)];

    this.agents.push({
      id: this.nextAgentId++,
      x: startX,
      y: startY,
      width: 22 + Math.random() * 4,
      height: 48 + Math.random() * 8,
      vx: 0,
      vy: 0,
      targetX,
      targetY,
      speed: this.params.baseSpeed * (0.85 + Math.random() * 0.3),
      active: true,
      colorVariation: color,
      pathIndex: 0,
      spawnTime: Date.now(),
    });
  }

  /**
   * Physics update step
   */
  public update(dtSeconds: number = 0.033): SyntheticAgent[] {
    const now = Date.now();
    const spawnIntervalMs = 60000 / (this.params.entryRatePerMinute * this.params.incomingFlowMultiplier);

    // Dynamic spawning if entrance is not closed
    if (!this.params.entranceClosed && now - this.lastSpawnTime > spawnIntervalMs) {
      if (this.agents.length < this.params.agentCount * 1.5) {
        this.spawnAgent(false);
      }
      this.lastSpawnTime = now;
    }

    const corridorX1 = 180;
    const corridorX2 = 310;
    const corridorY1 = 80;
    const corridorY2 = 280;

    for (const agent of this.agents) {
      if (!agent.active) continue;

      let effectiveTargetX = agent.targetX;
      let effectiveTargetY = agent.targetY;

      // Check alternate pathway routing
      if (this.params.alternatePathOpen && agent.x > 150 && agent.x < 320) {
        // Divert through bypass at bottom of screen
        effectiveTargetY = 320;
      }

      // Check zone restriction
      if (this.params.zoneRestricted && agent.x > corridorX1 - 20 && agent.x < corridorX2 + 20) {
        // Slow down significantly due to restricted access
        agent.speed = Math.min(agent.speed, 6);
      }

      // Desired vector
      const dx = effectiveTargetX - agent.x;
      const dy = effectiveTargetY - agent.y;
      const dist = Math.hypot(dx, dy);

      if (dist < 20) {
        // Reached destination, recycle or pick new target
        if (agent.x > this.width - 50 || agent.x < 50) {
          // Recycle
          agent.x = Math.random() > 0.5 ? 30 : this.width - 30;
          agent.y = 80 + Math.random() * (this.height - 160);
          agent.targetX = agent.x < 100 ? this.width - 30 : 30;
        } else {
          agent.targetX = Math.random() > 0.5 ? this.width - 30 : 30;
        }
      }

      // Social force: collision avoidance with neighboring agents
      let repelX = 0;
      let repelY = 0;
      for (const other of this.agents) {
        if (other.id !== agent.id && other.active) {
          const sepX = agent.x - other.x;
          const sepY = agent.y - other.y;
          const sepDist = Math.hypot(sepX, sepY);
          const comfortDistance = 24;

          if (sepDist > 0 && sepDist < comfortDistance) {
            const force = (comfortDistance - sepDist) / comfortDistance;
            repelX += (sepX / sepDist) * force * 15;
            repelY += (sepY / sepDist) * force * 15;
          }
        }
      }

      // Target steering
      let dirX = dist > 0 ? dx / dist : 0;
      let dirY = dist > 0 ? dy / dist : 0;

      // Bottleneck corridor constraint
      if (agent.x >= corridorX1 && agent.x <= corridorX2) {
        // Confined Y corridor
        if (agent.y < corridorY1 + 10) repelY += 12;
        if (agent.y > corridorY2 - 10) repelY -= 12;
      }

      // Update velocities
      const targetVx = dirX * agent.speed + repelX;
      const targetVy = dirY * agent.speed + repelY;

      agent.vx = agent.vx * 0.7 + targetVx * 0.3;
      agent.vy = agent.vy * 0.7 + targetVy * 0.3;

      agent.x += agent.vx * dtSeconds;
      agent.y += agent.vy * dtSeconds;

      // Keep within bounds
      agent.x = Math.max(15, Math.min(this.width - 15, agent.x));
      agent.y = Math.max(30, Math.min(this.height - 30, agent.y));
    }

    return this.agents;
  }

  public getAgents(): SyntheticAgent[] {
    return this.agents;
  }

  /**
   * Draws the synthetic environment floor, corridor walls, alternate bypass, and pedestrians
   */
  public renderToCanvas(ctx: CanvasRenderingContext2D, privacyBlur: boolean = false): void {
    ctx.save();

    // 1. Base floor (transit concourse styling)
    ctx.fillStyle = this.params.isLowLight ? '#080d14' : '#0f172a';
    ctx.fillRect(0, 0, this.width, this.height);

    // Floor tile grid
    ctx.strokeStyle = this.params.isLowLight ? '#131e2e' : '#1e293b';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x < this.width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.height);
      ctx.stroke();
    }
    for (let y = 0; y < this.height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.width, y);
      ctx.stroke();
    }

    // 2. Bottleneck corridor boundaries
    ctx.fillStyle = this.params.zoneRestricted
      ? 'rgba(239, 68, 68, 0.15)'
      : 'rgba(245, 158, 11, 0.08)';
    ctx.fillRect(180, 80, 130, 200);

    ctx.strokeStyle = this.params.zoneRestricted ? '#ef4444' : '#f59e0b';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.strokeRect(180, 80, 130, 200);
    ctx.setLineDash([]);

    // 3. Alternate path visualization if enabled
    if (this.params.alternatePathOpen) {
      ctx.fillStyle = 'rgba(16, 185, 129, 0.15)';
      ctx.fillRect(170, 290, 150, 45);
      ctx.strokeStyle = '#10b981';
      ctx.strokeRect(170, 290, 150, 45);
      ctx.fillStyle = '#10b981';
      ctx.font = '10px monospace';
      ctx.fillText('ALT BYPASS ROUTE (ACTIVE)', 178, 316);
    }

    // 4. Entrance status
    if (this.params.entranceClosed) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.3)';
      ctx.fillRect(10, 30, 30, this.height - 60);
      ctx.fillStyle = '#ef4444';
      ctx.font = 'bold 11px sans-serif';
      ctx.save();
      ctx.translate(28, 200);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText('ENTRANCE CLOSED', 0, 0);
      ctx.restore();
    }

    // 5. Render agents
    for (const agent of this.agents) {
      if (!agent.active) continue;

      ctx.save();
      if (privacyBlur) {
        // Privacy blur or silhouette representation
        ctx.fillStyle = 'rgba(148, 163, 184, 0.5)';
        ctx.beginPath();
        ctx.arc(agent.x, agent.y - 12, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillRect(agent.x - 6, agent.y - 5, 12, 22);
      } else {
        // Synthetic pedestrian sprite (head, shoulders, shadow)
        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
        ctx.beginPath();
        ctx.ellipse(agent.x, agent.y + 14, 8, 4, 0, 0, Math.PI * 2);
        ctx.fill();

        // Torso / body
        ctx.fillStyle = this.params.isLowLight ? '#334155' : agent.colorVariation;
        ctx.beginPath();
        ctx.roundRect(agent.x - 7, agent.y - 6, 14, 20, 3);
        ctx.fill();

        // Head
        ctx.fillStyle = this.params.isLowLight ? '#475569' : '#e2e8f0';
        ctx.beginPath();
        ctx.arc(agent.x, agent.y - 12, 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // Low light vignette filter
    if (this.params.isLowLight) {
      const vignette = ctx.createRadialGradient(
        this.width / 2,
        this.height / 2,
        80,
        this.width / 2,
        this.height / 2,
        this.width / 1.5
      );
      vignette.addColorStop(0, 'rgba(0, 0, 0, 0.4)');
      vignette.addColorStop(1, 'rgba(0, 0, 0, 0.88)');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, this.width, this.height);
    }

    ctx.restore();
  }

  /**
   * Computes What-If impact simulation matrix
   */
  public evaluateWhatIf(state: WhatIfScenarioState): WhatIfScenarioState {
    let simulatedRisk = 0.25;

    // Entrance closed reduces inflow by 80%
    if (state.entranceClosed) {
      simulatedRisk -= 0.25;
    }

    // Alternate path open provides 35% relief to bottleneck
    if (state.alternatePathOpen) {
      simulatedRisk -= 0.30;
    }

    // Restricting zone adds congestion to adjacent zones
    if (state.zoneRestricted) {
      simulatedRisk += 0.28;
    }

    // Capacity multiplier
    if (state.pathwayCapacityMultiplier > 1.0) {
      simulatedRisk -= (state.pathwayCapacityMultiplier - 1.0) * 0.2;
    } else if (state.pathwayCapacityMultiplier < 1.0) {
      simulatedRisk += (1.0 - state.pathwayCapacityMultiplier) * 0.35;
    }

    // Flow rate multiplier
    simulatedRisk += (state.incomingFlowMultiplier - 1.0) * 0.3;

    simulatedRisk = Math.max(0.05, Math.min(0.95, simulatedRisk));

    let simulatedState: any = 'NORMAL';
    if (simulatedRisk > 0.65) simulatedState = 'HIGH-RISK CONGESTION';
    else if (simulatedRisk > 0.35) simulatedState = 'INCREASING';

    const zoneDensityShift: Record<string, number> = {
      'zone-a': state.entranceClosed ? -65 : Math.round((state.incomingFlowMultiplier - 1) * 40),
      'zone-b': state.alternatePathOpen
        ? -42
        : state.zoneRestricted
        ? +55
        : Math.round((state.incomingFlowMultiplier - 1) * 35),
      'zone-c': state.alternatePathOpen ? +15 : Math.round((state.incomingFlowMultiplier - 1) * 20),
      'zone-d': Math.round((state.incomingFlowMultiplier - 1) * 10),
    };

    const estimatedClearanceTimeSeconds = Math.round(
      Math.max(15, (simulatedRisk * 120) / state.pathwayCapacityMultiplier)
    );

    return {
      ...state,
      simulatedRisk: Number(simulatedRisk.toFixed(2)),
      simulatedState,
      zoneDensityShift,
      estimatedClearanceTimeSeconds,
    };
  }
}
