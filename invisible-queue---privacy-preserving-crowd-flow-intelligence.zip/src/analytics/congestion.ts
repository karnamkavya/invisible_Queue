import { CongestionAnalysis, CongestionEvidence, CongestionState, CrowdZone, TrackedPerson } from '../types';
import { FlowAnalysisResult } from './flow';

export interface CongestionHistoryEntry {
  timestamp: number;
  score: number;
  totalPeople: number;
  avgSpeed: number;
  density: number;
}

export class CongestionEngine {
  private history: CongestionHistoryEntry[] = [];
  private previousCount: number = 0;
  private previousTimestamp: number = Date.now();

  public evaluate(
    tracks: TrackedPerson[],
    zones: CrowdZone[],
    flow: FlowAnalysisResult,
    timestamp: number = Date.now()
  ): CongestionAnalysis {
    const totalCount = tracks.length;
    const dt = Math.max(0.5, (timestamp - this.previousTimestamp) / 1000);

    // 1. Density signal (average across active zones, or max zone density)
    let maxDensity = 0;
    let avgZoneDensity = 0;
    if (zones.length > 0) {
      maxDensity = Math.max(...zones.map((z) => z.density));
      avgZoneDensity = zones.reduce((acc, z) => acc + z.density, 0) / zones.length;
    }
    // Normalized density score (0.0 at 0 p/m², 1.0 at >= 3.0 p/m²)
    const densityScore = Math.min(1.0, maxDensity / 2.5);

    // 2. Speed deceleration signal (normal pedestrian walking speed is ~25-45 px/s)
    // Low speed when crowd is present indicates stall/gridlock
    let speedDecelerationScore = 0;
    if (totalCount > 4) {
      if (flow.averageSpeed < 8) speedDecelerationScore = 1.0;
      else if (flow.averageSpeed < 18) speedDecelerationScore = 0.7;
      else if (flow.averageSpeed < 28) speedDecelerationScore = 0.35;
      else speedDecelerationScore = 0.05;
    }

    // 3. Direction conflict signal (opposing counter-currents)
    const directionConflictScore = Math.min(1.0, flow.conflictIndex * 1.5);

    // 4. Dwell time signal (prolonged stagnation)
    const avgDwell =
      totalCount > 0 ? tracks.reduce((acc, t) => acc + t.dwellTime, 0) / totalCount : 0;
    const dwellScore = Math.min(1.0, avgDwell / 45); // >45s avg dwell = max score

    // 5. Inflow / Outflow imbalance signal
    const totalInflow = zones.reduce((acc, z) => acc + z.entryRate, 0);
    const totalOutflow = zones.reduce((acc, z) => acc + z.exitRate, 0);
    const netInflowDelta = totalInflow - totalOutflow;
    let inflowImbalanceScore = 0;
    if (netInflowDelta > 15) inflowImbalanceScore = 0.9;
    else if (netInflowDelta > 6) inflowImbalanceScore = 0.6;
    else if (netInflowDelta > 0) inflowImbalanceScore = 0.3;
    else inflowImbalanceScore = 0.0;

    // 6. Crowd growth rate
    const growthRatePerSecond = (totalCount - this.previousCount) / dt;
    const growthScore = Math.max(0, Math.min(1.0, growthRatePerSecond / 1.5));

    this.previousCount = totalCount;
    this.previousTimestamp = timestamp;

    // Multi-factor weighted composite score
    // Density alone is NEVER sufficient for high-risk
    const compositeScore =
      densityScore * 0.28 +
      speedDecelerationScore * 0.25 +
      directionConflictScore * 0.18 +
      dwellScore * 0.14 +
      inflowImbalanceScore * 0.10 +
      growthScore * 0.05;

    const clampedScore = Number(Math.min(1.0, Math.max(0.0, compositeScore)).toFixed(3));

    // Determine state
    let state: CongestionState = 'NORMAL';
    if (clampedScore >= 0.65 || (densityScore > 0.75 && speedDecelerationScore > 0.6)) {
      state = 'HIGH-RISK CONGESTION';
    } else if (clampedScore >= 0.32 || (densityScore > 0.45 && inflowImbalanceScore > 0.4)) {
      state = 'INCREASING';
    } else {
      state = 'NORMAL';
    }

    // Build evidence list
    const evidence: CongestionEvidence[] = [];

    if (maxDensity > 1.8) {
      evidence.push({
        factor: 'High Density',
        description: `Peak zone density reached ${maxDensity} people/m² (Threshold: 1.8)`,
        severity: maxDensity > 2.5 ? 'critical' : 'moderate',
        value: `${maxDensity} p/m²`,
      });
    } else if (maxDensity > 0.9) {
      evidence.push({
        factor: 'Rising Density',
        description: `Zone density elevated at ${maxDensity} people/m²`,
        severity: 'low',
        value: `${maxDensity} p/m²`,
      });
    }

    if (totalCount > 4 && flow.averageSpeed < 18) {
      evidence.push({
        factor: 'Movement Deceleration',
        description: `Average crowd transit speed dropped to ${flow.averageSpeed} px/s`,
        severity: flow.averageSpeed < 10 ? 'critical' : 'moderate',
        value: `${flow.averageSpeed} px/s`,
      });
    }

    if (flow.directionConflicts.length > 0) {
      evidence.push({
        factor: 'Counter-Flow Collision',
        description: `${flow.directionConflicts.length} intersecting opposing movement trajectories detected`,
        severity: flow.directionConflicts.length > 3 ? 'critical' : 'moderate',
        value: `${flow.directionConflicts.length} conflicts`,
      });
    }

    if (netInflowDelta > 5) {
      evidence.push({
        factor: 'Inflow Outflow Imbalance',
        description: `Inflow (${totalInflow}/min) significantly exceeds outflow (${totalOutflow}/min)`,
        severity: netInflowDelta > 15 ? 'critical' : 'moderate',
        value: `+${netInflowDelta}/min net`,
      });
    }

    if (avgDwell > 25) {
      evidence.push({
        factor: 'Prolonged Dwell Time',
        description: `Pedestrian dwell time averaging ${Math.round(avgDwell)}s in scene`,
        severity: avgDwell > 45 ? 'critical' : 'low',
        value: `${Math.round(avgDwell)}s`,
      });
    }

    if (evidence.length === 0) {
      evidence.push({
        factor: 'Nominal Fluid Flow',
        description: 'Movement velocity, density, and entry/exit ratios within standard transit parameters',
        severity: 'low',
        value: 'Optimal',
      });
    }

    // Record history
    this.history.push({
      timestamp,
      score: clampedScore,
      totalPeople: totalCount,
      avgSpeed: flow.averageSpeed,
      density: maxDensity,
    });
    if (this.history.length > 120) {
      this.history.shift();
    }

    return {
      state,
      score: clampedScore,
      evidence,
      timestamp,
      contributingFactors: {
        densityContribution: Number((densityScore * 0.28).toFixed(2)),
        speedDecelerationContribution: Number((speedDecelerationScore * 0.25).toFixed(2)),
        directionConflictContribution: Number((directionConflictScore * 0.18).toFixed(2)),
        dwellTimeContribution: Number((dwellScore * 0.14).toFixed(2)),
        inflowImbalanceContribution: Number((inflowImbalanceScore * 0.10).toFixed(2)),
      },
    };
  }

  public getHistory(): CongestionHistoryEntry[] {
    return this.history;
  }
}
