import React from 'react';
import { PrivacyConfig } from '../types';
import { PrivacyAuditReport } from '../privacy/privacyManager';
import { 
  ShieldCheck, 
  X, 
  Check, 
  EyeOff, 
  Database, 
  Lock, 
  FileCheck, 
  Download 
} from 'lucide-react';

interface PrivacyPanelProps {
  isOpen: boolean;
  onClose: () => void;
  config: PrivacyConfig;
  onUpdateConfig: (newConfig: Partial<PrivacyConfig>) => void;
  auditReport: PrivacyAuditReport;
}

export const PrivacyPanel: React.FC<PrivacyPanelProps> = ({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  auditReport,
}) => {
  if (!isOpen) return null;

  const downloadAuditReport = () => {
    const jsonStr = JSON.stringify(auditReport, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `privacy_audit_certificate_${Date.now()}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                Privacy Architecture & Configuration
              </h2>
              <p className="text-xs text-slate-400">
                Guaranteed zero-biometric crowd intelligence
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Core Privacy Guarantees (Section 13) */}
          <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-xl p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-300 mb-3 flex items-center gap-1.5">
              <FileCheck className="w-4 h-4 text-emerald-400" />
              <span>Fundamental Architectural Guarantees</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-200">
              <div className="flex items-center gap-2 p-2 rounded bg-slate-900/60 border border-emerald-900/50">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>No Face Recognition</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-slate-900/60 border border-emerald-900/50">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>No Identity Recognition</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-slate-900/60 border border-emerald-900/50">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>No Permanent Person IDs</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-slate-900/60 border border-emerald-900/50">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Anonymous Temporary Tracking</span>
              </div>
              <div className="flex items-center gap-2 p-2 rounded bg-slate-900/60 border border-emerald-900/50 sm:col-span-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>No Raw-Video Storage By Default (Zero-Disk Footprint)</span>
              </div>
            </div>
          </div>

          {/* Configuration Toggles */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Visual Privacy Controls
            </h3>

            <div>
              <label className="text-slate-300 font-medium mb-1.5 block">
                Visual Obfuscation Level:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'none', label: 'Standard Anonymous' },
                  { id: 'blur-boxes', label: 'Video Gaussian Blur' },
                  { id: 'silhouette', label: 'Wireframe Silhouette' },
                  { id: 'heatmap-only', label: 'Thermal Dispersion Only' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => onUpdateConfig({ blurLevel: item.id as any })}
                    className={`p-2.5 rounded-lg border text-center transition-all cursor-pointer ${
                      config.blurLevel === item.id
                        ? 'bg-cyan-950 border-cyan-500 text-cyan-200 font-bold'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-2 border-t border-slate-700/60">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <div className="font-semibold text-slate-200">
                    Strict Temporary ID Expiration (&le; 3 Seconds)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Purges track records from volatile RAM as soon as a person exits camera bounds.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config.strictTemporaryIds}
                  onChange={(e) => onUpdateConfig({ strictTemporaryIds: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <div className="font-semibold text-slate-200">
                    Zero Raw Footage Storage Policy
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Prohibits saving uncompressed video frames to disk or external cloud servers.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config.zeroRawFootageStorage}
                  onChange={(e) => onUpdateConfig({ zeroRawFootageStorage: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <div className="font-semibold text-slate-200">
                    Metadata-Only Event Logging
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Limits telemetry logs strictly to timestamp, zone ID, and aggregated counts.
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config.metadataOnlyLogging}
                  onChange={(e) => onUpdateConfig({ metadataOnlyLogging: e.target.checked })}
                  className="rounded accent-emerald-500 w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* Audit Verification Certificate */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-4 flex items-center justify-between gap-4">
            <div>
              <div className="font-bold text-slate-200 text-xs">
                Audited Compliance Status: 100% Privacy-Preserving
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Complies with GDPR Article 25 and EU AI Act Non-Biometric Safety Standard.
              </div>
            </div>
            <button
              onClick={downloadAuditReport}
              className="bg-slate-700 hover:bg-slate-600 text-white px-3 py-1.5 rounded-lg flex items-center gap-1.5 cursor-pointer font-medium shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Audit JSON</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
