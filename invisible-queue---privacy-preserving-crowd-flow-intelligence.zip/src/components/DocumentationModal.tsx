import React, { useState } from 'react';
import { 
  ARCHITECTURE_MARKDOWN, 
  DEMO_SCRIPT_30_60, 
  LINKEDIN_POST_CONTENT 
} from '../docs/documentation';
import { 
  FileText, 
  X, 
  Copy, 
  Check, 
  Share2, 
  Cpu, 
  AlertTriangle, 
  Layers 
} from 'lucide-react';

interface DocumentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DocumentationModal: React.FC<DocumentationModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'linkedin' | 'script' | 'architecture' | 'limitations'>('linkedin');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center">
              <FileText className="w-4 h-4 text-sky-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                Documentation, Scripts & LinkedIn Post
              </h2>
              <p className="text-xs text-slate-400">
                System specification, architecture diagram, and presentation copy
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="bg-slate-950 px-5 border-b border-slate-800 flex gap-2 overflow-x-auto text-xs">
          {[
            { id: 'linkedin', label: 'LinkedIn Project Post' },
            { id: 'script', label: '30-60s Demo Script' },
            { id: 'architecture', label: 'Architecture Diagram' },
            { id: 'limitations', label: 'Limitations & Future Work' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`py-3 px-3 border-b-2 font-semibold transition-all cursor-pointer ${
                activeTab === tab.id
                  ? 'border-sky-400 text-sky-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {/* Tab 1: LinkedIn Project Description */}
          {activeTab === 'linkedin' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-bold">
                  LinkedIn-Ready Project Announcement (Section 33):
                </span>
                <button
                  onClick={() => handleCopy(LINKEDIN_POST_CONTENT)}
                  className="bg-slate-800 hover:bg-slate-700 text-sky-400 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 cursor-pointer font-medium"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy to Clipboard'}</span>
                </button>
              </div>
              <textarea
                readOnly
                value={LINKEDIN_POST_CONTENT}
                rows={16}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-slate-300 font-mono text-[11px] leading-relaxed resize-none focus:outline-none"
              />
            </div>
          )}

          {/* Tab 2: 30-60s Demo Script */}
          {activeTab === 'script' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-bold">
                  Suggested 30-To-60 Second Presentation Script:
                </span>
                <button
                  onClick={() => handleCopy(DEMO_SCRIPT_30_60)}
                  className="bg-slate-800 hover:bg-slate-700 text-sky-400 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 cursor-pointer font-medium"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy to Clipboard'}</span>
                </button>
              </div>
              <textarea
                readOnly
                value={DEMO_SCRIPT_30_60}
                rows={16}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-slate-300 font-mono text-[11px] leading-relaxed resize-none focus:outline-none"
              />
            </div>
          )}

          {/* Tab 3: Architecture Diagram */}
          {activeTab === 'architecture' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-bold">
                  System Architecture Pipeline (Section 2 & 29):
                </span>
                <button
                  onClick={() => handleCopy(ARCHITECTURE_MARKDOWN)}
                  className="bg-slate-800 hover:bg-slate-700 text-sky-400 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 cursor-pointer font-medium"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Markdown'}</span>
                </button>
              </div>
              <pre className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-cyan-300 font-mono text-[11px] overflow-x-auto leading-relaxed">
                {ARCHITECTURE_MARKDOWN}
              </pre>
            </div>
          )}

          {/* Tab 4: Limitations & Future Work */}
          {activeTab === 'limitations' && (
            <div className="space-y-4">
              <div className="bg-slate-800/70 border border-slate-700 rounded-xl p-4 space-y-2">
                <h3 className="font-bold text-amber-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>Real-World System Limitations (Section 30)</span>
                </h3>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Severe Crowd Overlap:</strong> In extremely high-density surges (&gt;5 people/m²), 2D monocular camera angles suffer severe occlusion where individuals merge into single contours.</li>
                  <li><strong>Lighting & Glare:</strong> Drastic changes in ambient illumination can decrease detection recall. Our system counters this with real-time luminance monitoring and honesty warnings.</li>
                  <li><strong>Camera Perspective Angle:</strong> Oblique angles distort ground-plane distance metrics; calibrated homography matrices are recommended for production deployments.</li>
                  <li><strong>Prediction Non-Determinism:</strong> Future crowd behavior cannot be predicted with 100% certainty. The system displays explicit uncertainty bounds and confidence percentages.</li>
                </ul>
              </div>

              <div className="bg-slate-800/70 border border-slate-700 rounded-xl p-4 space-y-2">
                <h3 className="font-bold text-cyan-300 flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span>Future Technical Scope</span>
                </h3>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Multi-Camera 3D Homography:</strong> Combining multiple synchronized IP cameras into a single continuous bird&apos;s-eye spatial coordinate space.</li>
                  <li><strong>Edge TPU Acceleration:</strong> Compiling the anonymous tracking pipeline to run on sub-15W edge neural accelerators (Coral / Jetson Nano).</li>
                  <li><strong>Dynamic Turnstile Integration:</strong> Direct API triggers to automated fare gates to automatically throttle high-risk arrival surges.</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
