/**
 * INVISIBLE QUEUE — Privacy-Preserving Crowd Flow Intelligence
 * Real-time AI computer vision and edge analytics platform.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  CrowdZone, 
  DemoScenarioType, 
  Detection, 
  EarlyPrediction, 
  OperationalRecommendation, 
  PrivacyConfig, 
  RobustnessWarnings, 
  SystemEventLog, 
  TrackedPerson, 
  VideoSourceType, 
  WhatIfScenarioState,
  BenchmarkMetrics,
  CongestionAnalysis
} from './types';

// Core Engines
import { AnonymousTracker } from './tracking/tracker';
import { PersonDetector } from './vision/detector';
import { DEFAULT_ZONES, ZoneAnalyzer } from './analytics/zones';
import { FlowAnalyzer, FlowAnalysisResult } from './analytics/flow';
import { CrowdHeatmap } from './analytics/heatmap';
import { CongestionEngine } from './analytics/congestion';
import { EarlyCongestionPredictor } from './prediction/predictor';
import { AnomalyDetector } from './anomaly/detector';
import { SyntheticCrowdSimulator } from './simulation/simulator';
import { RecommendationEngine } from './recommendations/engine';
import { DEFAULT_PRIVACY_CONFIG, PrivacyManager } from './privacy/privacyManager';
import { BenchmarkRunner, INITIAL_BENCHMARK_STATE } from './evaluation/benchmark';

// UI Components
import { Header } from './components/Header';
import { ScenarioSelector } from './components/ScenarioSelector';
import { LiveMonitor } from './components/LiveMonitor';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { RiskPanel } from './components/RiskPanel';
import { AnomalyPanel } from './components/AnomalyPanel';
import { RecommendationPanel } from './components/RecommendationPanel';
import { EventLog } from './components/EventLog';
import { WhatIfSimulatorModal } from './components/WhatIfSimulatorModal';
import { PrivacyPanel } from './components/PrivacyPanel';
import { EvaluationModal } from './components/EvaluationModal';
import { TestRunnerModal } from './components/TestRunnerModal';
import { LinkedInPresentationModal } from './components/LinkedInPresentationModal';
import { DocumentationModal } from './components/DocumentationModal';

export default function App() {
  // Engine Instances (persisted across renders)
  const trackerRef = useRef<AnonymousTracker>(new AnonymousTracker());
  const detectorRef = useRef<PersonDetector>(new PersonDetector(640, 360));
  const zoneAnalyzerRef = useRef<ZoneAnalyzer>(new ZoneAnalyzer(DEFAULT_ZONES));
  const flowAnalyzerRef = useRef<FlowAnalyzer>(new FlowAnalyzer());
  const heatmapRef = useRef<CrowdHeatmap>(new CrowdHeatmap(640, 360));
  const congestionEngineRef = useRef<CongestionEngine>(new CongestionEngine());
  const predictorRef = useRef<EarlyCongestionPredictor>(new EarlyCongestionPredictor());
  const anomalyDetectorRef = useRef<AnomalyDetector>(new AnomalyDetector());
  const recommendationEngineRef = useRef<RecommendationEngine>(new RecommendationEngine());
  const privacyManagerRef = useRef<PrivacyManager>(new PrivacyManager());
  const benchmarkRunnerRef = useRef<BenchmarkRunner>(new BenchmarkRunner());
  const simulatorRef = useRef<SyntheticCrowdSimulator>(
    new SyntheticCrowdSimulator(640, 360, { scenario: 'NORMAL_FLOW' })
  );

  // Core Application States
  const [sourceType, setSourceType] = useState<VideoSourceType>('synthetic');
  const [currentScenario, setCurrentScenario] = useState<DemoScenarioType>('NORMAL_FLOW');
  const [environment, setEnvironment] = useState('Central Railway Concourse');
  const [tracks, setTracks] = useState<TrackedPerson[]>([]);
  const [zones, setZones] = useState<CrowdZone[]>(DEFAULT_ZONES);
  const [flow, setFlow] = useState<FlowAnalysisResult>({
    averageSpeed: 0,
    dominantAngleDeg: 0,
    dominantDirection: 'East (→)',
    directionConflicts: [],
    conflictIndex: 0,
    suddenDirectionChangesCount: 0,
    flowCohesion: 1.0,
  });

  const [congestion, setCongestion] = useState<CongestionAnalysis>({
    state: 'NORMAL',
    score: 0.12,
    evidence: [
      {
        factor: 'Nominal Fluid Flow',
        description: 'Movement velocity, density, and entry/exit ratios within standard parameters',
        severity: 'low',
        value: 'Optimal',
      },
    ],
    timestamp: Date.now(),
    contributingFactors: {
      densityContribution: 0.05,
      speedDecelerationContribution: 0.02,
      directionConflictContribution: 0.01,
      dwellTimeContribution: 0.02,
      inflowImbalanceContribution: 0.02,
    },
  });

  const [prediction, setPrediction] = useState<EarlyPrediction>({
    state: 'NORMAL',
    score: 0.15,
    confidence: 84,
    horizonSeconds: 60,
    isLowConfidence: false,
    factorsInfluencing: ['Stable laminar throughput equilibrium'],
    historicalTrend: [],
    projectedRiskCurve: [],
  });

  const [anomalies, setAnomalies] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<OperationalRecommendation[]>([]);
  const [isRecsLoading, setIsRecsLoading] = useState(false);
  const [eventLogs, setEventLogs] = useState<SystemEventLog[]>([]);
  const [privacyConfig, setPrivacyConfig] = useState<PrivacyConfig>(DEFAULT_PRIVACY_CONFIG);

  const [warnings, setWarnings] = useState<RobustnessWarnings>({
    isLowLight: false,
    lowLightValue: 128,
    isCameraShaking: false,
    shakeMagnitude: 0,
    isHighOcclusion: false,
    occlusionRatio: 0,
    trackingConfidenceDrop: false,
    averageConfidence: 0.92,
  });

  const [whatIfState, setWhatIfState] = useState<WhatIfScenarioState>({
    entranceClosed: false,
    alternatePathOpen: false,
    zoneRestricted: false,
    pathwayCapacityMultiplier: 1.0,
    incomingFlowMultiplier: 1.0,
    simulatedRisk: 0.25,
    simulatedState: 'NORMAL',
    zoneDensityShift: { 'zone-a': 0, 'zone-b': 0, 'zone-c': 0, 'zone-d': 0 },
    estimatedClearanceTimeSeconds: 30,
  });

  const [benchmarkMetrics, setBenchmarkMetrics] = useState<BenchmarkMetrics>(INITIAL_BENCHMARK_STATE);

  // Performance Telemetry
  const [fps, setFps] = useState(54);
  const [latencyMs, setLatencyMs] = useState(16);

  // Modal Open States
  const [isWhatIfOpen, setIsWhatIfOpen] = useState(false);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [isEvaluationOpen, setIsEvaluationOpen] = useState(false);
  const [isTestsOpen, setIsTestsOpen] = useState(false);
  const [isDocsOpen, setIsDocsOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  // Ref for previous congestion state to log transitions
  const prevCongestionStateRef = useRef<string>('NORMAL');

  // Add system log entry helper
  const addLog = useCallback(
    (type: SystemEventLog['type'], zone: string, event: string, confidence: number, recommendation?: string) => {
      setEventLogs((prev) => [
        {
          id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          timestamp: Date.now(),
          type,
          zone,
          event,
          confidence,
          recommendation,
        },
        ...prev.slice(0, 49),
      ]);
    },
    []
  );

  // Initial recommendation fetch
  useEffect(() => {
    recommendationEngineRef.current
      .fetchRecommendations(congestion, zones, anomalies, environment)
      .then((recs) => setRecommendations(recs));
  }, []);

  // Scenario Switcher Handler
  const handleSelectScenario = useCallback(
    (scenario: DemoScenarioType) => {
      setCurrentScenario(scenario);
      simulatorRef.current.setScenario(scenario);
      addLog(
        'CONGESTION_CHANGE',
        'Global Scene',
        `Switched demo test scenario to: ${scenario}`,
        0.95
      );
    },
    [addLog]
  );

  // 1-Click START DEMO button
  const handleStartDemo = useCallback(() => {
    setSourceType('synthetic');
    trackerRef.current.reset();
    heatmapRef.current.reset();
    handleSelectScenario('NORMAL_FLOW');
    addLog(
      'PRIVACY_AUDIT',
      'System Core',
      'Demo initialized. Anonymous tracking active. Zero biometric storage.',
      1.0
    );
  }, [handleSelectScenario, addLog]);

  // Main Processing Pipeline Step (Frame by frame)
  const processPipeline = useCallback(
    (detections: Detection[], options: { isLowLight?: boolean; isCameraShaking?: boolean; shakeMagnitude?: number } = {}) => {
      const startTime = performance.now();
      const now = Date.now();

      // 1. Anonymous Tracking
      const updatedTracks = trackerRef.current.update(detections, now);
      setTracks(updatedTracks);

      // 2. Dynamic Zone Analysis
      const updatedZones = zoneAnalyzerRef.current.update(updatedTracks, now);
      setZones([...updatedZones]);

      // 3. Movement Flow Analysis
      const flowResult = flowAnalyzerRef.current.analyze(updatedTracks);
      setFlow(flowResult);

      // 4. Heatmap Update
      const personPositions = updatedTracks.map((t) => t.currentPos);
      heatmapRef.current.update(personPositions);

      // 5. Multi-Signal Congestion Evaluation
      const congestionResult = congestionEngineRef.current.evaluate(
        updatedTracks,
        updatedZones,
        flowResult,
        now
      );
      setCongestion(congestionResult);

      // Check for state shift log
      if (congestionResult.state !== prevCongestionStateRef.current) {
        addLog(
          'CONGESTION_CHANGE',
          'Concourse',
          `Congestion state shifted to: ${congestionResult.state}`,
          congestionResult.score
        );
        prevCongestionStateRef.current = congestionResult.state;
      }

      // 6. Early Congestion Time-Series Prediction
      const history = congestionEngineRef.current.getHistory();
      const predictionResult = predictorRef.current.predict(congestionResult, history);
      setPrediction(predictionResult);

      // 7. Anomaly Detection
      const detectedAnomalies = anomalyDetectorRef.current.detect(
        updatedTracks,
        updatedZones,
        flowResult,
        now
      );
      if (detectedAnomalies.length > 0) {
        setAnomalies([...anomalyDetectorRef.current.getHistory()]);
        detectedAnomalies.forEach((a) => {
          addLog('ANOMALY_DETECTED', a.zoneName, a.description, a.confidence);
        });
      }

      // 8. Robustness & Drawback Monitoring
      const totalOccluded = updatedTracks.filter((t) => t.isOccluded).length;
      const occlusionRatio = updatedTracks.length > 0 ? totalOccluded / updatedTracks.length : 0;
      const avgConf =
        updatedTracks.length > 0
          ? updatedTracks.reduce((acc, t) => acc + t.confidence, 0) / updatedTracks.length
          : 0.95;

      const isLowLight = options.isLowLight || simulatorRef.current.getParams().isLowLight;

      setWarnings({
        isLowLight: !!isLowLight,
        lowLightValue: isLowLight ? 32 : 145,
        isCameraShaking: !!options.isCameraShaking,
        shakeMagnitude: options.shakeMagnitude || 0,
        isHighOcclusion: occlusionRatio > 0.35,
        occlusionRatio,
        trackingConfidenceDrop: avgConf < 0.65,
        averageConfidence: Number(avgConf.toFixed(2)),
      });

      // Periodic AI Recommendation refresh
      if (Math.random() < 0.05) {
        recommendationEngineRef.current
          .fetchRecommendations(congestionResult, updatedZones, anomalyDetectorRef.current.getHistory(), environment)
          .then((recs) => setRecommendations(recs));
      }

      const elapsed = performance.now() - startTime;
      setLatencyMs(Math.round(elapsed));
    },
    [environment, addLog]
  );

  // Synthetic Simulator Tick
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let lastFpsUpdate = performance.now();

    const loop = (currentTime: number) => {
      const dt = Math.min(0.1, (currentTime - lastTime) / 1000);
      lastTime = currentTime;

      // Update FPS
      frameCount++;
      if (currentTime - lastFpsUpdate >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastFpsUpdate = currentTime;
      }

      if (sourceType === 'synthetic') {
        // Update physics
        const agents = simulatorRef.current.update(dt);
        const simParams = simulatorRef.current.getParams();

        // Generate synthetic detections with realistic noise & overlap
        const detections = detectorRef.current.generateDetectionsFromSyntheticAgents(agents, {
          isLowLight: simParams.isLowLight,
          occlusionDrop: currentScenario === 'OVERLAPPING_PEOPLE',
        });

        // Run core pipeline
        processPipeline(detections, {
          isLowLight: simParams.isLowLight,
        });
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [sourceType, currentScenario, processPipeline]);

  // Frame processing for Webcam & Uploaded video feeds
  const handleProcessVideoFrame = useCallback(
    (ctx: CanvasRenderingContext2D, width: number, height: number) => {
      const analysis = detectorRef.current.analyzeCanvasFrame(ctx, width, height);
      processPipeline(analysis.detections, {
        isLowLight: analysis.isLowLight,
        isCameraShaking: analysis.isCameraShaking,
        shakeMagnitude: analysis.shakeMagnitude,
      });
    },
    [processPipeline]
  );

  // Render Synthetic Background to Live Canvas
  const handleRenderSyntheticFrame = useCallback((ctx: CanvasRenderingContext2D, privacyBlur: boolean) => {
    simulatorRef.current.renderToCanvas(ctx, privacyBlur);
  }, []);

  // What-If Simulator Update
  const handleUpdateWhatIf = useCallback((partial: Partial<WhatIfScenarioState>) => {
    setWhatIfState((prev) => {
      const next = { ...prev, ...partial };
      return simulatorRef.current.evaluateWhatIf(next);
    });
  }, []);

  // Apply What-If parameters to live simulator
  const handleApplyWhatIfToLive = useCallback(() => {
    simulatorRef.current.setParams({
      entranceClosed: whatIfState.entranceClosed,
      alternatePathOpen: whatIfState.alternatePathOpen,
      zoneRestricted: whatIfState.zoneRestricted,
      incomingFlowMultiplier: whatIfState.incomingFlowMultiplier,
    });
    addLog(
      'CONGESTION_CHANGE',
      'Mitigation Action',
      `Applied What-If Policy: Entrance=${whatIfState.entranceClosed ? 'CLOSED' : 'OPEN'}, AlternatePath=${whatIfState.alternatePathOpen ? 'ACTIVE' : 'OFF'}, Flow=${whatIfState.incomingFlowMultiplier}x`,
      0.95
    );
  }, [whatIfState, addLog]);

  // Manual AI Recommendation Refresh
  const handleManualRefreshRecs = async () => {
    setIsRecsLoading(true);
    try {
      const recs = await recommendationEngineRef.current.fetchRecommendations(
        congestion,
        zones,
        anomalies,
        environment
      );
      setRecommendations(recs);
    } finally {
      setIsRecsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30">
      {/* 1. Header with System Health, Venue Selector & Launcher Buttons */}
      <Header
        fps={fps}
        latencyMs={latencyMs}
        environment={environment}
        onEnvironmentChange={setEnvironment}
        onStartDemo={handleStartDemo}
        onOpenPresentation={() => setIsPresentationOpen(true)}
        onOpenWhatIf={() => setIsWhatIfOpen(true)}
        onOpenEvaluation={() => setIsEvaluationOpen(true)}
        onOpenTests={() => setIsTestsOpen(true)}
        onOpenDocs={() => setIsDocsOpen(true)}
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        activeScenarioName={currentScenario}
      />

      {/* Main Workspace Body */}
      <main className="max-w-7xl mx-auto w-full p-4 space-y-4 flex-1">
        {/* 2. Automated Demo Scenario Quick-Switcher (Section 18 & 19) */}
        <ScenarioSelector
          currentScenario={currentScenario}
          onSelectScenario={handleSelectScenario}
          isSynthetic={sourceType === 'synthetic'}
        />

        {/* 3. Primary Intelligence Grid (Live Monitor + Risk + Analytics) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Column: Live Edge Video / Synthetic Monitor (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            <LiveMonitor
              tracks={tracks}
              zones={zones}
              sourceType={sourceType}
              onSourceTypeChange={setSourceType}
              onVideoUpload={(file) => {
                setSourceType('uploaded');
                addLog('PRIVACY_AUDIT', 'Input Source', `Uploaded video: ${file.name}`, 1.0);
              }}
              heatmap={heatmapRef.current}
              warnings={warnings}
              privacyConfig={privacyConfig}
              onUpdatePrivacy={(newConf) => {
                setPrivacyConfig((prev) => ({ ...prev, ...newConf }));
                privacyManagerRef.current.updateConfig(newConf);
              }}
              renderSyntheticFrame={handleRenderSyntheticFrame}
              onProcessWebcamFrame={handleProcessVideoFrame}
              onProcessVideoFrame={handleProcessVideoFrame}
            />

            {/* Analytics Dashboard (KPIs + Dynamic Zones Breakdown) */}
            <AnalyticsPanel tracks={tracks} zones={zones} flow={flow} />
          </div>

          {/* Right Column: Risk Panel + Anomaly Stream + AI Suggestions (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Multi-Signal Congestion State & Early Time-Series Prediction */}
            <RiskPanel
              congestion={congestion}
              prediction={prediction}
              onHorizonChange={(sec) => {
                predictorRef.current.setHorizon(sec);
                setPrediction(predictorRef.current.predict(congestion, congestionEngineRef.current.getHistory()));
              }}
            />

            {/* Anomaly Detection Stream */}
            <AnomalyPanel
              anomalies={anomalies}
              onClear={() => {
                anomalyDetectorRef.current.clearHistory();
                setAnomalies([]);
              }}
            />

            {/* Operational AI Recommendations */}
            <RecommendationPanel
              recommendations={recommendations}
              onRefresh={handleManualRefreshRecs}
              isLoading={isRecsLoading}
            />
          </div>
        </div>

        {/* 4. System Event & Privacy Audit Log */}
        <EventLog logs={eventLogs} onClear={() => setEventLogs([])} />
      </main>

      {/* 5. Modals & Guided Experience Walkthroughs */}
      <WhatIfSimulatorModal
        isOpen={isWhatIfOpen}
        onClose={() => setIsWhatIfOpen(false)}
        whatIfState={whatIfState}
        onUpdateState={handleUpdateWhatIf}
        onApplyToLive={handleApplyWhatIfToLive}
      />

      <PrivacyPanel
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        config={privacyConfig}
        onUpdateConfig={(newConf) => {
          setPrivacyConfig((prev) => ({ ...prev, ...newConf }));
          privacyManagerRef.current.updateConfig(newConf);
        }}
        auditReport={privacyManagerRef.current.generateAuditReport()}
      />

      <EvaluationModal
        isOpen={isEvaluationOpen}
        onClose={() => setIsEvaluationOpen(false)}
        metrics={benchmarkMetrics}
        onUpdateMetrics={setBenchmarkMetrics}
        runner={benchmarkRunnerRef.current}
      />

      <TestRunnerModal
        isOpen={isTestsOpen}
        onClose={() => setIsTestsOpen(false)}
      />

      <LinkedInPresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
        onTriggerScenario={handleSelectScenario}
      />

      <DocumentationModal
        isOpen={isDocsOpen}
        onClose={() => setIsDocsOpen(false)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-3 px-4 text-center mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            INVISIBLE QUEUE &copy; 2026 • Privacy-Preserving Crowd Flow Intelligence
          </span>
          <span className="text-[11px] text-slate-500 font-mono">
            Zero Biometrics • Anonymous Temporal Tracking • Multi-Signal Congestion Prediction
          </span>
        </div>
      </footer>
    </div>
  );
}
