import React from 'react';
import { DemoScenarioType } from '../types';
import { 
  CheckCircle, 
  TrendingUp, 
  AlertTriangle, 
  Shuffle, 
  Users, 
  Moon, 
  Sparkles
} from 'lucide-react';

interface ScenarioSelectorProps {
  currentScenario: DemoScenarioType;
  onSelectScenario: (scenario: DemoScenarioType) => void;
  isSynthetic: boolean;
}

export const SCENARIO_ITEMS: {
  id: DemoScenarioType;
  title: string;
  expectedState: string;
  icon: React.ReactNode;
  desc: string;
  badgeColor: string;
}[] = [
  {
    id: 'NORMAL_FLOW',
    title: 'A. Normal Flow',
    expectedState: 'NORMAL',
    icon: <CheckCircle className="w-4 h-4 text-emerald-400" />,
    desc: 'Pedestrians transit smoothly across zones at nominal velocity (35 px/s).',
    badgeColor: 'bg-emerald-950 text-emerald-300 border-emerald-800',
  },
  {
    id: 'GRADUAL_CONGESTION',
    title: 'B. Gradual Congestion',
    expectedState: 'INCREASING',
    icon: <TrendingUp className="w-4 h-4 text-amber-400" />,
    desc: 'Inflow rate elevates, bottleneck corridor begins accumulating passengers.',
    badgeColor: 'bg-amber-950 text-amber-300 border-amber-800',
  },
  {
    id: 'HIGH_CONGESTION',
    title: 'C. High Congestion',
    expectedState: 'HIGH-RISK CONGESTION',
    icon: <AlertTriangle className="w-4 h-4 text-rose-400" />,
    desc: 'Dense crowd stall, low movement speed (<8 px/s), severe bottleneck blockage.',
    badgeColor: 'bg-rose-950 text-rose-300 border-rose-800',
  },
  {
    id: 'SUDDEN_CROWD_MOVEMENT',
    title: 'D. Sudden Crowd Movement',
    expectedState: 'UNUSUAL PATTERN',
    icon: <Shuffle className="w-4 h-4 text-cyan-400" />,
    desc: 'Pedestrians suddenly reverse course or turn sharply; triggers anomaly detection.',
    badgeColor: 'bg-cyan-950 text-cyan-300 border-cyan-800',
  },
  {
    id: 'OVERLAPPING_PEOPLE',
    title: 'E. Overlapping People',
    expectedState: 'OCCLUSION TEST',
    icon: <Users className="w-4 h-4 text-purple-400" />,
    desc: 'Pedestrians converge in close proximity; validates temporal track persistence.',
    badgeColor: 'bg-purple-950 text-purple-300 border-purple-800',
  },
  {
    id: 'LOW_LIGHT',
    title: 'F. Low-Light Scenario',
    expectedState: 'LOW CONFIDENCE',
    icon: <Moon className="w-4 h-4 text-indigo-400" />,
    desc: 'Poor illumination lowers detection certainty; system triggers honesty warning.',
    badgeColor: 'bg-indigo-950 text-indigo-300 border-indigo-800',
  },
];

export const ScenarioSelector: React.FC<ScenarioSelectorProps> = ({
  currentScenario,
  onSelectScenario,
  isSynthetic,
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 shadow-lg">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Automated Demo Scenarios
          </h2>
        </div>
        {!isSynthetic && (
          <span className="text-[11px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/60">
            Switch to Synthetic Mode to test preset scenarios
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {SCENARIO_ITEMS.map((item) => {
          const isSelected = currentScenario === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectScenario(item.id)}
              className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer relative overflow-hidden ${
                isSelected
                  ? 'bg-slate-800 border-cyan-500/80 shadow-md shadow-cyan-900/30 ring-1 ring-cyan-500/50'
                  : 'bg-slate-900/70 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-xs font-bold text-slate-200 truncate">
                  {item.title}
                </span>
                {item.icon}
              </div>
              <div className="flex items-center justify-between gap-1 mt-1">
                <span
                  className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${item.badgeColor}`}
                >
                  {item.expectedState}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                {item.desc}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
