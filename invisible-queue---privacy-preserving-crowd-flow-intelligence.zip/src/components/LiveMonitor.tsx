import React, { useRef, useEffect, useState } from 'react';
import { 
  CrowdZone, 
  PrivacyConfig, 
  RobustnessWarnings, 
  TrackedPerson, 
  VideoSourceType 
} from '../types';
import { 
  Camera, 
  Video, 
  Cpu, 
  Eye, 
  Flame, 
  Grid, 
  Navigation, 
  AlertTriangle, 
  ShieldCheck, 
  Upload, 
  Maximize2,
  RefreshCw
} from 'lucide-react';
import { CrowdHeatmap } from '../analytics/heatmap';

interface LiveMonitorProps {
  tracks: TrackedPerson[];
  zones: CrowdZone[];
  sourceType: VideoSourceType;
  onSourceTypeChange: (source: VideoSourceType) => void;
  onVideoUpload: (file: File) => void;
  heatmap: CrowdHeatmap;
  warnings: RobustnessWarnings;
  privacyConfig: PrivacyConfig;
  onUpdatePrivacy: (config: Partial<PrivacyConfig>) => void;
  renderSyntheticFrame: (ctx: CanvasRenderingContext2D, privacyBlur: boolean) => void;
  onProcessWebcamFrame: (ctx: CanvasRenderingContext2D, width: number, height: number) => void;
  onProcessVideoFrame: (ctx: CanvasRenderingContext2D, width: number, height: number) => void;
}

export const LiveMonitor: React.FC<LiveMonitorProps> = ({
  tracks,
  zones,
  sourceType,
  onSourceTypeChange,
  onVideoUpload,
  heatmap,
  warnings,
  privacyConfig,
  onUpdatePrivacy,
  renderSyntheticFrame,
  onProcessWebcamFrame,
  onProcessVideoFrame,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Layer toggles
  const [showBoundingBoxes, setShowBoundingBoxes] = useState(true);
  const [showArrows, setShowArrows] = useState(true);
  const [showZones, setShowZones] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(true);
  const [heatmapOpacity, setHeatmapOpacity] = useState(0.6);
  const [webcamError, setWebcamError] = useState<string | null>(null);
  const [webcamStream, setWebcamStream] = useState<MediaStream | null>(null);

  // Initialize and handle video/webcam playback
  useEffect(() => {
    let active = true;

    if (sourceType === 'webcam') {
      setWebcamError(null);
      navigator.mediaDevices
        ?.getUserMedia({ video: { width: 640, height: 360 } })
        .then((stream) => {
          if (!active) {
            stream.getTracks().forEach((t) => t.stop());
            return;
          }
          setWebcamStream(stream);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play().catch(() => {});
          }
        })
        .catch((err) => {
          setWebcamError(
            `Unable to access webcam (${err.message || 'Permission denied or no camera device found'}). Please use Synthetic Simulation Mode.`
          );
        });
    } else {
      if (webcamStream) {
        webcamStream.getTracks().forEach((t) => t.stop());
        setWebcamStream(null);
      }
      if (videoRef.current && sourceType !== 'uploaded') {
        videoRef.current.srcObject = null;
      }
    }

    return () => {
      active = false;
      if (webcamStream) {
        webcamStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [sourceType]);

  // Main canvas animation render loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;

      // 1. Render Base Video or Synthetic Stream
      if (sourceType === 'synthetic') {
        renderSyntheticFrame(ctx, privacyConfig.blurLevel === 'silhouette' || privacyConfig.blurLevel === 'blur-boxes');
      } else if (videoRef.current && videoRef.current.readyState >= 2) {
        // Draw video frame to canvas
        ctx.save();
        if (privacyConfig.blurLevel === 'blur-boxes') {
          ctx.filter = 'blur(4px)';
        } else if (privacyConfig.blurLevel === 'silhouette') {
          ctx.filter = 'grayscale(100%) contrast(150%) brightness(80%)';
        }
        ctx.drawImage(videoRef.current, 0, 0, width, height);
        ctx.restore();

        // Feed frame to detector
        if (sourceType === 'webcam') {
          onProcessWebcamFrame(ctx, width, height);
        } else if (sourceType === 'uploaded') {
          onProcessVideoFrame(ctx, width, height);
        }
      } else {
        // Placeholder background
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, width, height);
      }

      // If Heatmap-Only privacy mode is selected, blank the visual stream
      if (privacyConfig.blurLevel === 'heatmap-only') {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.fillRect(0, 0, width, height);
      }

      // 2. Render Live Heatmap Layer
      if (showHeatmap) {
        heatmap.renderTo(ctx, heatmapOpacity, width, height);
      }

      // 3. Render Zone Boundaries
      if (showZones) {
        for (const zone of zones) {
          ctx.save();
          ctx.beginPath();
          if (zone.polygon.length > 0) {
            ctx.moveTo(zone.polygon[0].x, zone.polygon[0].y);
            for (let i = 1; i < zone.polygon.length; i++) {
              ctx.lineTo(zone.polygon[i].x, zone.polygon[i].y);
            }
            ctx.closePath();
          }

          // Shading
          ctx.fillStyle = `${zone.color}15`;
          ctx.fill();

          // Border
          ctx.strokeStyle = zone.color;
          ctx.lineWidth = 1.5;
          ctx.setLineDash([4, 4]);
          ctx.stroke();

          // Zone Tag Label
          if (zone.polygon.length > 0) {
            const labelX = zone.polygon[0].x + 6;
            const labelY = zone.polygon[0].y + 16;
            ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
            ctx.fillRect(labelX - 3, labelY - 12, 105, 16);
            ctx.fillStyle = zone.color;
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText(`${zone.name.split(' ')[0]}: ${zone.currentCount}p`, labelX, labelY);
          }
          ctx.restore();
        }
      }

      // 4. Render Anonymous Bounding Boxes & IDs
      if (showBoundingBoxes && privacyConfig.blurLevel !== 'heatmap-only') {
        for (const track of tracks) {
          ctx.save();
          const { x, y, width: bw, height: bh } = track.bbox;

          // Box color based on speed and confidence
          let boxColor = '#38bdf8'; // sky blue
          if (track.isOccluded) boxColor = '#a855f7'; // purple for occluded / persistence
          else if (track.speed < 6 && tracks.length > 4) boxColor = '#f59e0b'; // amber for stationary

          ctx.strokeStyle = boxColor;
          ctx.lineWidth = 1.8;
          ctx.strokeRect(x, y, bw, bh);

          // Anonymous Identifier Tag (Person-01)
          const tagText = `${track.trackId} [${Math.round(track.confidence * 100)}%]`;
          ctx.font = '10px monospace';
          const textMetrics = ctx.measureText(tagText);
          const tagW = textMetrics.width + 8;
          const tagH = 14;

          ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
          ctx.fillRect(x, Math.max(0, y - tagH), tagW, tagH);

          ctx.fillStyle = boxColor;
          ctx.fillText(tagText, x + 4, Math.max(10, y - 3));

          // Direction Trajectory tail
          if (track.history.length > 1) {
            ctx.beginPath();
            ctx.moveTo(track.history[0].x, track.history[0].y);
            for (let i = 1; i < track.history.length; i++) {
              ctx.lineTo(track.history[i].x, track.history[i].y);
            }
            ctx.strokeStyle = `${boxColor}60`;
            ctx.lineWidth = 1.2;
            ctx.stroke();
          }

          ctx.restore();
        }
      }

      // 5. Render Movement Direction Arrows
      if (showArrows && privacyConfig.blurLevel !== 'heatmap-only') {
        for (const track of tracks) {
          if (track.speed > 5) {
            ctx.save();
            const cx = track.currentPos.x;
            const cy = track.currentPos.y;
            const arrowLen = Math.min(26, track.speed * 0.6);
            const headLen = 6;
            const toX = cx + Math.cos(track.angle) * arrowLen;
            const toY = cy + Math.sin(track.angle) * arrowLen;

            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.lineTo(toX, toY);
            ctx.strokeStyle = '#22d3ee';
            ctx.lineWidth = 2;
            ctx.stroke();

            // Arrow head
            ctx.beginPath();
            ctx.moveTo(toX, toY);
            ctx.lineTo(
              toX - headLen * Math.cos(track.angle - Math.PI / 6),
              toY - headLen * Math.sin(track.angle - Math.PI / 6)
            );
            ctx.lineTo(
              toX - headLen * Math.cos(track.angle + Math.PI / 6),
              toY - headLen * Math.sin(track.angle + Math.PI / 6)
            );
            ctx.fillStyle = '#22d3ee';
            ctx.fill();
            ctx.restore();
          }
        }
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [
    sourceType,
    tracks,
    zones,
    showBoundingBoxes,
    showArrows,
    showZones,
    showHeatmap,
    heatmapOpacity,
    privacyConfig,
  ]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('video/')) {
        alert('Invalid file format. Please upload an MP4, WebM, or supported video file.');
        return;
      }
      if (file.size > 150 * 1024 * 1024) {
        alert('File size exceeds 150MB limit.');
        return;
      }
      onVideoUpload(file);
      if (videoRef.current) {
        videoRef.current.src = URL.createObjectURL(file);
        videoRef.current.loop = true;
        videoRef.current.play().catch(() => {});
      }
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl flex flex-col">
      {/* Top Bar with Source Switcher & Stats */}
      <div className="bg-slate-800/80 px-3.5 py-2 border-b border-slate-700/80 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-900 px-2 py-1 rounded-lg border border-slate-700/70">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wide">
              Live Edge Feed
            </span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Tracked: <strong className="text-cyan-400">{tracks.length}</strong> persons
          </span>
        </div>

        {/* Source Switcher Buttons */}
        <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-lg border border-slate-700/70 text-xs">
          <button
            onClick={() => onSourceTypeChange('synthetic')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              sourceType === 'synthetic'
                ? 'bg-cyan-600 text-white font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Synthetic Simulator</span>
          </button>

          <button
            onClick={() => onSourceTypeChange('webcam')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              sourceType === 'webcam'
                ? 'bg-cyan-600 text-white font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Webcam</span>
          </button>

          <button
            onClick={() => {
              onSourceTypeChange('uploaded');
              fileInputRef.current?.click();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
              sourceType === 'uploaded'
                ? 'bg-cyan-600 text-white font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Video</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={handleFileUpload}
          />
        </div>
      </div>

      {/* Main Canvas Viewport */}
      <div className="relative aspect-[16/9] w-full bg-black overflow-hidden flex items-center justify-center">
        {/* Hidden HTML5 video element for webcam or video playback */}
        <video
          ref={videoRef}
          className="hidden"
          playsInline
          muted
          autoPlay
          loop
        />

        {/* Real-time Render Canvas */}
        <canvas
          ref={canvasRef}
          width={640}
          height={360}
          className="w-full h-full object-contain"
        />

        {/* Webcam Error Fallback Banner */}
        {sourceType === 'webcam' && webcamError && (
          <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-6 text-center">
            <AlertTriangle className="w-10 h-10 text-amber-400 mb-2" />
            <h3 className="text-sm font-bold text-slate-100 mb-1">Webcam Inaccessible</h3>
            <p className="text-xs text-slate-400 max-w-md mb-4">{webcamError}</p>
            <button
              onClick={() => onSourceTypeChange('synthetic')}
              className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold px-4 py-2 rounded-lg"
            >
              Switch to Synthetic Crowd Simulator
            </button>
          </div>
        )}

        {/* Failure-Safe Robustness Warning Banners (Section 14 & 15) */}
        {warnings.isLowLight && (
          <div className="absolute top-3 left-3 right-3 bg-amber-950/90 border border-amber-600 text-amber-200 px-3 py-2 rounded-lg text-xs flex items-center gap-2 shadow-lg backdrop-blur-sm animate-pulse">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="font-bold">LOW CONFIDENCE:</span> Low ambient lighting detected. Detection accuracy may decrease; improve lighting or reposition camera.
            </div>
          </div>
        )}

        {warnings.isCameraShaking && !warnings.isLowLight && (
          <div className="absolute top-3 left-3 right-3 bg-amber-950/90 border border-amber-600 text-amber-200 px-3 py-2 rounded-lg text-xs flex items-center gap-2 shadow-lg backdrop-blur-sm">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="font-bold">CAMERA MOTION:</span> High frame jitter detected. Stabilization filter active; flow vectors may experience temporary noise.
            </div>
          </div>
        )}

        {/* Watermark / Guarantee Badge */}
        <div className="absolute bottom-2 left-2 bg-slate-950/80 backdrop-blur-sm border border-slate-800 px-2 py-1 rounded text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
          <span>ANONYMOUS TEMPORARY TRACKING • ZERO BIOMETRICS</span>
        </div>
      </div>

      {/* Layer Control Bar */}
      <div className="bg-slate-800/90 px-3 py-2 border-t border-slate-700/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-medium text-[11px]">Display Layers:</span>

          <label className="flex items-center gap-1 cursor-pointer text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={showBoundingBoxes}
              onChange={(e) => setShowBoundingBoxes(e.target.checked)}
              className="rounded accent-cyan-500"
            />
            <Eye className="w-3 h-3 text-cyan-400" />
            <span>Boxes & IDs</span>
          </label>

          <label className="flex items-center gap-1 cursor-pointer text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={showArrows}
              onChange={(e) => setShowArrows(e.target.checked)}
              className="rounded accent-cyan-500"
            />
            <Navigation className="w-3 h-3 text-cyan-400" />
            <span>Flow Vectors</span>
          </label>

          <label className="flex items-center gap-1 cursor-pointer text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={showZones}
              onChange={(e) => setShowZones(e.target.checked)}
              className="rounded accent-cyan-500"
            />
            <Grid className="w-3 h-3 text-amber-400" />
            <span>Zones</span>
          </label>

          <label className="flex items-center gap-1 cursor-pointer text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={showHeatmap}
              onChange={(e) => setShowHeatmap(e.target.checked)}
              className="rounded accent-cyan-500"
            />
            <Flame className="w-3 h-3 text-rose-400" />
            <span>Heatmap</span>
          </label>

          {showHeatmap && (
            <div className="flex items-center gap-1 ml-1 text-[11px] text-slate-400">
              <span>Opacity:</span>
              <input
                type="range"
                min="0.2"
                max="0.9"
                step="0.05"
                value={heatmapOpacity}
                onChange={(e) => setHeatmapOpacity(parseFloat(e.target.value))}
                className="w-16 accent-rose-500 cursor-pointer"
              />
            </div>
          )}
        </div>

        {/* Privacy View Switcher */}
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 text-[11px]">Privacy Mode:</span>
          <select
            value={privacyConfig.blurLevel}
            onChange={(e) => onUpdatePrivacy({ blurLevel: e.target.value as any })}
            className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-0.5 rounded text-[11px] focus:outline-none cursor-pointer"
          >
            <option value="none">Standard Anonymous View</option>
            <option value="blur-boxes">Visual Blur on Video</option>
            <option value="silhouette">Silhouette Wireframe</option>
            <option value="heatmap-only">Heatmap Dispersion Only</option>
          </select>
        </div>
      </div>
    </div>
  );
};
