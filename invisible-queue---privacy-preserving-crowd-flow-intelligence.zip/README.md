# INVISIBLE QUEUE — Privacy-Preserving Crowd Flow Intelligence

> **Real-time AI computer vision system that analyzes crowd movement from video/camera feeds to detect, understand, and predict congestion WITHOUT identifying people.**

---

## 1. Project Goal & Philosophy

**DETECT → TRACK → UNDERSTAND → PREDICT → ALERT → RECOMMEND**

Unlike conventional surveillance systems that rely on invasive biometric profiling or facial recognition, **Invisible Queue** is engineered from the ground up on **Privacy-by-Design**:
- ❌ **No face recognition**
- ❌ **No identity recognition or permanent profiles**
- ❌ **No biometric embeddings or template storage**
- ❌ **No raw camera footage archived by default**
- ✅ **Anonymous temporary tracking (e.g. Person-01, Person-02)**
- ✅ **Automatic track expiration when individuals leave the scene**
- ✅ **Multi-signal congestion detection (never density alone)**
- ✅ **Early predictive time-series forecasting**
- ✅ **Transparent uncertainty reporting ("Prediction confidence is low")**
- ✅ **Interactive What-If mitigation simulator**

---

## 2. Core Pipeline Architecture

```
Camera / Video / Synthetic Stream
              ↓
   Person Detection (Vision)
              ↓
  Anonymous Multi-Person Tracker
    (ByteTrack-Lite / IoU + Velocity)
              ↓
      Dynamic Crowd Zones
    (Entrance / Corridor / Concourse / Exit)
              ↓
  Density + Flow Direction Analysis
    (Vector Field + Collision Angle)
              ↓
   Multi-Signal Congestion Engine
  (Density, Speed, Conflicts, Dwell, Inflow)
              ↓
Early Congestion Prediction & Anomaly Engine
  ("Unusual movement pattern detected")
              ↓
    AI Recommendation Engine
   (Gemini 2.5 Flash / Heuristics)
              ↓
Professional Dashboard & What-If Simulator
```

---

## 3. Technology Stack

- **Frontend Application**: React 19, TypeScript, Tailwind CSS, Lucide Icons, HTML5 Canvas 2D Engine.
- **Computer Vision & Tracking**:
  - In-browser real-time frame difference & contour aspect-ratio pedestrian detector.
  - ByteTrack-lite Hungarian/greedy IoU association with velocity smoothing.
  - Continuous thermal density heatmap engine with spatial decay.
  - Ray-casting point-in-polygon dynamic zone geometry.
- **Backend & AI Engine**:
  - Express.js with Vite middleware.
  - `@google/genai` with Gemini 2.5 Flash for operational crowd safety recommendations.
  - Deterministic expert heuristic fallback for offline or zero-API-key environments.
- **Evaluation & Testing**:
  - Automated test suite covering counting, zoning, density, congestion scoring, and file validation.
  - Synthetic ground-truth benchmark suite for Precision, Recall, HOTA tracking stability, and latency.

---

## 4. Quickstart & Installation

### Requirements:
- Node.js >= 18.0.0
- npm >= 9.0.0

### One-Command Startup:
```bash
# 1. Install dependencies
npm install

# 2. (Optional) Provide your Gemini API key in .env for AI recommendations
echo 'GEMINI_API_KEY="your-api-key-here"' > .env

# 3. Launch the full-stack development server
npm run dev
```

Visit `http://localhost:3000` in your web browser.

---

## 5. Input Modes Supported

1. **Synthetic Crowd Simulator (Default / 1-Click Demo)**:
   - Includes 6 pre-configured scenarios:
     - Scenario A: Normal Flow
     - Scenario B: Gradual Congestion
     - Scenario C: High Congestion
     - Scenario D: Sudden Crowd Movement
     - Scenario E: Overlapping People (heavy occlusion)
     - Scenario F: Low-Light / Poor-Quality (triggers low-confidence failure safe)
2. **Live Webcam Mode**:
   - Accesses your connected camera via `navigator.mediaDevices.getUserMedia`.
   - Runs anonymous tracking directly on local video frames.
3. **Prerecorded / Uploaded Video Mode**:
   - Upload any MP4/WebM video file (with size limits and type validation).
   - Real-time frame processing on HTML5 canvas.

---

## 6. Real-World Robustness & Drawback Handling

| Real-World Challenge | Potential Problem | Invisible Queue Mitigation |
| :--- | :--- | :--- |
| **Low Light** | Detection accuracy drops | Real-time luminance monitoring; low-light warning banner; contrast boost. |
| **People Overlapping** | Detections merge together | Temporal track persistence (holds track for up to 30 frames); velocity projection. |
| **Fast Movement** | Tracker loses target | Velocity motion smoothing and dynamic search radius expansion. |
| **Partial Occlusion** | Target temporarily blocked | Grace period before track deletion; track re-association. |
| **Camera Shake** | Motion vectors distorted | Optical centroid stability monitoring; camera-motion jitter warning. |
| **False Congestion Alerts** | High density ≠ congestion | Multi-signal fusion: density (28%), speed (25%), flow conflict (18%), dwell (14%), balance (10%). |
| **Prediction Uncertainty** | Future cannot be known 100% | Honest confidence percentage; clear label: "Prediction confidence is low" when noisy. |

---

## 7. Automated Testing Commands

To run the automated verification suite inside the app:
- Click the **"Run Test Suite"** button in the header bar.
- Checks: Person Counting, Anonymous IDs, Point-in-Polygon, Zone Density, Inflow/Outflow Rates, Multi-Signal Scoring, Low-Confidence Suppression, Time-Series Prediction, Anomaly Neutral Wording, and Video Input Validation.

To run static TypeScript verification:
```bash
npm run lint
```

---

## 8. Limitations & Future Work

### Current Limitations:
1. **Monocular Perspective Occlusion**: Severe 3D crush (>5 people/m²) causes visual occlusion in single camera perspective.
2. **Static Camera Assumption**: Mobile handheld camera feeds require additional optical flow stabilization.
3. **Threshold Calibration**: Physical environments (stadiums vs. hospital hallways) require custom density baselines.

### Future Work:
- Multi-camera homography fusion onto a 3D digital twin.
- Edge TPU / ONNX Runtime WASM hardware acceleration.
- Direct integration with municipal emergency dispatch and dynamic transit gate signaling.

---

## 9. Ethics & Privacy Guarantee

- **Zero Face Recognition**: No face detector or landmark extractor is loaded.
- **Zero Identity Storage**: No databases of biometric fingerprints or identities exist.
- **Temporary Ephemeral IDs**: IDs like `Person-01` are purely volatile RAM counters that expire when the person departs.
- **Non-Guaranteed Disclaimers**: All predictions are labeled as predictions; all AI recommendations are labeled as suggestions.
