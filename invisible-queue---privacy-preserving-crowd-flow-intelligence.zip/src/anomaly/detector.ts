import { AnomalyEvent, CrowdZone, TrackedPerson } from '../types';
import { FlowAnalysisResult } from '../analytics/flow';

export class AnomalyDetector {
  private previousZoneCounts: Map<string, number> = new Map();
  private previousZoneSpeeds: Map<string, number> = new Map();
  private lastTriggerTime: Map<string, number> = new Map();
  private anomalyHistory: AnomalyEvent[] = [];

  public detect(
    tracks: TrackedPerson[],
    zones: CrowdZone[],
    flow: FlowAnalysisResult,
    now: number = Date.now()
  ): AnomalyEvent[] {
    const newAnomalies: AnomalyEvent[] = [];
    const cooldownMs = 8000; // 8 second cooldown per pattern type to avoid spamming

    // 1. Sudden crowd surge in specific zones (> 5 person surge in a short interval)
    for (const zone of zones) {
      const prevCount = this.previousZoneCounts.get(zone.id) ?? zone.currentCount;
      const countDelta = zone.currentCount - prevCount;

      if (countDelta >= 6) {
        const key = `surge-${zone.id}`;
        if (!this.lastTriggerTime.has(key) || now - (this.lastTriggerTime.get(key) || 0) > cooldownMs) {
          const anomaly: AnomalyEvent = {
            id: `anom-${now}-${Math.random().toString(36).substring(2, 6)}`,
            timestamp: now,
            zoneId: zone.id,
            zoneName: zone.name,
            patternType: 'Sudden Density Surge',
            confidence: 0.88,
            supportingMeasurements: {
              densityDelta: countDelta,
            },
            description: `Unusual movement pattern detected: Inflow wave surged by +${countDelta} people in ${zone.name}.`,
          };
          newAnomalies.push(anomaly);
          this.lastTriggerTime.set(key, now);
        }
      }

      // 2. Unexpected mass stopping: speed drops from > 25 px/s to < 5 px/s while people are present
      const prevSpeed = this.previousZoneSpeeds.get(zone.id) ?? zone.avgSpeed;
      if (zone.currentCount >= 4 && prevSpeed > 24 && zone.avgSpeed < 6) {
        const key = `stopping-${zone.id}`;
        if (!this.lastTriggerTime.has(key) || now - (this.lastTriggerTime.get(key) || 0) > cooldownMs) {
          const anomaly: AnomalyEvent = {
            id: `anom-${now}-${Math.random().toString(36).substring(2, 6)}`,
            timestamp: now,
            zoneId: zone.id,
            zoneName: zone.name,
            patternType: 'Unexpected Mass Stopping',
            confidence: 0.82,
            supportingMeasurements: {
              speedDelta: Number((zone.avgSpeed - prevSpeed).toFixed(1)),
            },
            description: `Unusual movement pattern detected: Abrupt deceleration observed in ${zone.name}.`,
          };
          newAnomalies.push(anomaly);
          this.lastTriggerTime.set(key, now);
        }
      }

      this.previousZoneCounts.set(zone.id, zone.currentCount);
      this.previousZoneSpeeds.set(zone.id, zone.avgSpeed);
    }

    // 3. Abnormal direction conflicts (opposing vector collision)
    if (flow.directionConflicts.length >= 3) {
      const key = 'conflict-cluster';
      if (!this.lastTriggerTime.has(key) || now - (this.lastTriggerTime.get(key) || 0) > cooldownMs) {
        const topConflict = flow.directionConflicts[0];
        const anomaly: AnomalyEvent = {
          id: `anom-${now}-${Math.random().toString(36).substring(2, 6)}`,
          timestamp: now,
          zoneId: 'cross-traffic',
          zoneName: 'Central Intersection',
          patternType: 'Abnormal Direction Conflict',
          confidence: 0.91,
          supportingMeasurements: {
            conflictAngle: topConflict.conflictAngleDeg,
          },
          description: `Unusual movement pattern detected: Multiple intersecting counter-flows at ~${topConflict.conflictAngleDeg}° collision trajectory.`,
        };
        newAnomalies.push(anomaly);
        this.lastTriggerTime.set(key, now);
      }
    }

    // 4. Sudden crowd rush / acceleration (> 10 sudden direction changes)
    if (flow.suddenDirectionChangesCount >= 6) {
      const key = 'sudden-rush';
      if (!this.lastTriggerTime.has(key) || now - (this.lastTriggerTime.get(key) || 0) > cooldownMs) {
        const anomaly: AnomalyEvent = {
          id: `anom-${now}-${Math.random().toString(36).substring(2, 6)}`,
          timestamp: now,
          zoneId: 'transit-area',
          zoneName: 'Active Corridor',
          patternType: 'Sudden Crowd Movement',
          confidence: 0.85,
          supportingMeasurements: {
            speedDelta: flow.averageSpeed,
          },
          description: `Unusual movement pattern detected: Synchronous direction divergence detected across ${flow.suddenDirectionChangesCount} tracks.`,
        };
        newAnomalies.push(anomaly);
        this.lastTriggerTime.set(key, now);
      }
    }

    if (newAnomalies.length > 0) {
      this.anomalyHistory.unshift(...newAnomalies);
      if (this.anomalyHistory.length > 50) {
        this.anomalyHistory = this.anomalyHistory.slice(0, 50);
      }
    }

    return newAnomalies;
  }

  public getHistory(): AnomalyEvent[] {
    return this.anomalyHistory;
  }

  public clearHistory(): void {
    this.anomalyHistory = [];
  }
}
