import React, { useState } from 'react';
import { WhatIfScenarioState } from '../types';
import { 
  SlidersHorizontal, 
  X, 
  AlertTriangle, 
  DoorClosed, 
  Route, 
  ShieldAlert, 
  Gauge, 
  Clock, 
  TrendingDown, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface WhatIfSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  whatIfState: WhatIfScenarioState;
  onUpdateState: (newState: Partial<WhatIfScenarioState>) => void;
  onApplyToLive: () => void;
}

export const WhatIfSimulatorModal: React.FC<WhatIfSimulatorModalProps> = ({
  isOpen,
  onClose,
  whatIfState,
  onUpdateState,
  onApplyToLive,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-800/90 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                What-If Queue Mitigation Simulator
              </h2>
              <p className="text-xs text-slate-400">
                Test crowd control policies before physical deployment
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mandatory Simulation Warning (Section 11 Requirement) */}
        <div className="bg-amber-950/70 border-b border-amber-800/80 px-5 py-2.5 flex items-center gap-2 text-amber-300 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="font-bold tracking-wide">
            SIMULATION — NOT A GUARANTEED REAL-WORLD PREDICTION
          </span>
        </div>

        <div className="p-5 overflow-y-auto space-y-6 flex-1">
          {/* Controls Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Action Toggles */}
            <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-4 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Operational Interventions
              </h3>

              {/* Toggle 1: Close Entrance */}
              <button
                onClick={() => onUpdateState({ entranceClosed: !whatIfState.entranceClosed })}
                className={`w-full p-3 rounded-lg border text-left flex items-center justify-between transition-all cursor-pointer ${
                  whatIfState.entranceClosed
                    ? 'bg-rose-950/80 border-rose-600 text-rose-200'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <DoorClosed className={`w-4 h-4 ${whatIfState.entranceClosed ? 'text-rose-400' : 'text-slate-400'}`} />
                  <div>
                    <div className="text-xs font-bold">
                      [ {whatIfState.entranceClosed ? 'Entrance Closed' : 'Close Main Entrance'} ]
                    </div>
                    <div className="text-[11px] opacity-80">
                      Halts incoming flow wave at turnstiles
                    </div>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold">
                  {whatIfState.entranceClosed ? 'ACTIVE' : 'OFF'}
                </span>
              </button>

              {/* Toggle 2: Open Alternate Path */}
              <button
                onClick={() => onUpdateState({ alternatePathOpen: !whatIfState.alternatePathOpen })}
                className={`w-full p-3 rounded-lg border text-left flex items-center justify-between transition-all cursor-pointer ${
                  whatIfState.alternatePathOpen
                    ? 'bg-emerald-950/80 border-emerald-600 text-emerald-200'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Route className={`w-4 h-4 ${whatIfState.alternatePathOpen ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <div>
                    <div className="text-xs font-bold">
                      [ {whatIfState.alternatePathOpen ? 'Bypass Corridor Open' : 'Open Alternate Path'} ]
                    </div>
                    <div className="text-[11px] opacity-80">
                      Diverts 35% of flow away from Zone B bottleneck
                    </div>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold">
                  {whatIfState.alternatePathOpen ? 'ACTIVE' : 'OFF'}
                </span>
              </button>

              {/* Toggle 3: Restrict Zone B */}
              <button
                onClick={() => onUpdateState({ zoneRestricted: !whatIfState.zoneRestricted })}
                className={`w-full p-3 rounded-lg border text-left flex items-center justify-between transition-all cursor-pointer ${
                  whatIfState.zoneRestricted
                    ? 'bg-amber-950/80 border-amber-600 text-amber-200'
                    : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShieldAlert className={`w-4 h-4 ${whatIfState.zoneRestricted ? 'text-amber-400' : 'text-slate-400'}`} />
                  <div>
                    <div className="text-xs font-bold">
                      [ {whatIfState.zoneRestricted ? 'Zone B Restricted' : 'Restrict Bottleneck Corridor'} ]
                    </div>
                    <div className="text-[11px] opacity-80">
                      Throttles transit throughput by 70%
                    </div>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold">
                  {whatIfState.zoneRestricted ? 'ACTIVE' : 'OFF'}
                </span>
              </button>
            </div>

            {/* Sliders */}
            <div className="bg-slate-800/60 border border-slate-700/70 rounded-xl p-4 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Flow & Capacity Parameters
              </h3>

              {/* Pathway Capacity Multiplier */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-300 font-medium">Pathway Capacity:</span>
                  <span className="font-mono text-cyan-400 font-bold">
                    {(whatIfState.pathwayCapacityMultiplier * 100).toFixed(0)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.1"
                  value={whatIfState.pathwayCapacityMultiplier}
                  onChange={(e) =>
                    onUpdateState({ pathwayCapacityMultiplier: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                  <span>50% (Constricted)</span>
                  <span>100% (Baseline)</span>
                  <span>200% (Expanded)</span>
                </div>
              </div>

              {/* Incoming Flow Multiplier */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-300 font-medium">Incoming Passenger Surge:</span>
                  <span className="font-mono text-amber-400 font-bold">
                    {(whatIfState.incomingFlowMultiplier * 100).toFixed(0)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.5"
                  step="0.1"
                  value={whatIfState.incomingFlowMultiplier}
                  onChange={(e) =>
                    onUpdateState({ incomingFlowMultiplier: parseFloat(e.target.value) })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                  <span>0.5x (Quiet)</span>
                  <span>1.0x (Nominal)</span>
                  <span>2.5x (Rush Hour)</span>
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Adjusting sliders dynamically recalculates estimated clearance times and spatial density shift.</span>
              </div>
            </div>
          </div>

          {/* Simulated Impact Results */}
          <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-3 flex items-center gap-2">
              <Gauge className="w-4 h-4 text-emerald-400" />
              <span>Simulated Projection Outcome</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
              {/* Simulated Risk */}
              <div className="bg-slate-900/90 border border-slate-700/80 p-3 rounded-lg text-center">
                <div className="text-[10px] uppercase text-slate-400 mb-1">
                  Simulated Risk Level
                </div>
                <div
                  className={`text-lg font-black tracking-wide ${
                    whatIfState.simulatedRisk > 0.65
                      ? 'text-rose-400'
                      : whatIfState.simulatedRisk > 0.35
                      ? 'text-amber-400'
                      : 'text-emerald-400'
                  }`}
                >
                  {whatIfState.simulatedState}
                </div>
                <div className="text-xs font-mono text-slate-400 mt-0.5">
                  Score: {Math.round(whatIfState.simulatedRisk * 100)} / 100
                </div>
              </div>

              {/* Clearance Time */}
              <div className="bg-slate-900/90 border border-slate-700/80 p-3 rounded-lg text-center">
                <div className="text-[10px] uppercase text-slate-400 mb-1">
                  Est. Queue Clearance Time
                </div>
                <div className="text-lg font-black text-cyan-400 font-mono">
                  {whatIfState.estimatedClearanceTimeSeconds}s
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Transit queue normalization
                </div>
              </div>

              {/* Bottleneck Shift */}
              <div className="bg-slate-900/90 border border-slate-700/80 p-3 rounded-lg text-center">
                <div className="text-[10px] uppercase text-slate-400 mb-1">
                  Bottleneck Corridor Shift
                </div>
                <div
                  className={`text-lg font-black font-mono ${
                    (whatIfState.zoneDensityShift['zone-b'] || 0) < 0
                      ? 'text-emerald-400'
                      : 'text-rose-400'
                  }`}
                >
                  {whatIfState.zoneDensityShift['zone-b'] || 0}%
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Predicted localized density change
                </div>
              </div>
            </div>

            {/* Zone-by-Zone Shift List */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
              {Object.entries(whatIfState.zoneDensityShift).map(([zoneId, shift]) => (
                <div
                  key={zoneId}
                  className="bg-slate-900/60 p-2 rounded border border-slate-800 flex items-center justify-between"
                >
                  <span className="text-slate-400 uppercase text-[10px]">{zoneId}:</span>
                  <span
                    className={`font-bold ${
                      shift < 0 ? 'text-emerald-400' : shift > 0 ? 'text-rose-400' : 'text-slate-300'
                    }`}
                  >
                    {shift > 0 ? `+${shift}%` : `${shift}%`}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex items-center justify-between">
          <div className="text-[11px] text-slate-400">
            Apply scenario changes directly to live simulation
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg border border-slate-600 text-xs font-medium text-slate-300 hover:bg-slate-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onApplyToLive();
                onClose();
              }}
              className="px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-md shadow-cyan-600/30 cursor-pointer flex items-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Apply to Simulator</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
