import { CongestionAnalysis, EarlyPrediction, PredictionState } from '../types';
import { CongestionHistoryEntry } from '../analytics/congestion';

export class EarlyCongestionPredictor {
  private horizonSeconds: number = 60; // default 60s

  public setHorizon(seconds: number): void {
    this.horizonSeconds = seconds;
  }

  public predict(
    currentAnalysis: CongestionAnalysis,
    history: CongestionHistoryEntry[],
    sampleCount: number = history.length
  ): EarlyPrediction {
    const minRequiredSamples = 8;
    const factorsInfluencing: string[] = [];

    // Insufficient historical measurements check
    if (sampleCount < minRequiredSamples) {
      return {
        state: currentAnalysis.state === 'HIGH-RISK CONGESTION' ? 'HIGH-RISK' : 'NORMAL',
        score: currentAnalysis.score,
        confidence: 24, // low
        horizonSeconds: this.horizonSeconds,
        isLowConfidence: true,
        lowConfidenceReason:
          'Insufficient historical time-series samples gathered (< 10 seconds of active tracking).',
        factorsInfluencing: ['Baseline Initialization'],
        historicalTrend: [],
        projectedRiskCurve: [
          { tOffset: 0, risk: currentAnalysis.score },
          { tOffset: this.horizonSeconds, risk: currentAnalysis.score },
        ],
      };
    }

    // Recent window of history
    const recent = history.slice(-20);
    const n = recent.length;

    // Linear regression on congestion scores over time
    let sumT = 0;
    let sumScore = 0;
    let sumTScore = 0;
    let sumT2 = 0;

    for (let i = 0; i < n; i++) {
      const t = i;
      const score = recent[i].score;
      sumT += t;
      sumScore += score;
      sumTScore += t * score;
      sumT2 += t * t;
    }

    const denominator = n * sumT2 - sumT * sumT;
    const slope = denominator !== 0 ? (n * sumTScore - sumT * sumScore) / denominator : 0;
    const intercept = (sumScore - slope * sumT) / n;

    // Velocity trend (is speed dropping?)
    const firstSpeed = recent[0].avgSpeed;
    const latestSpeed = recent[n - 1].avgSpeed;
    const speedDelta = latestSpeed - firstSpeed;

    // Density trend
    const firstDensity = recent[0].density;
    const latestDensity = recent[n - 1].density;
    const densityDelta = latestDensity - firstDensity;

    // Extrapolate score to horizon (normalized steps)
    const timeStepsAhead = Math.min(10, Math.round(this.horizonSeconds / 6));
    const projectedScoreRaw = intercept + slope * (n - 1 + timeStepsAhead);
    const projectedScore = Math.max(0.0, Math.min(1.0, projectedScoreRaw));

    // Calculate prediction confidence based on variance (R²) and sample volume
    let ssTot = 0;
    let ssRes = 0;
    const meanScore = sumScore / n;
    for (let i = 0; i < n; i++) {
      const actual = recent[i].score;
      const predicted = intercept + slope * i;
      ssTot += Math.pow(actual - meanScore, 2);
      ssRes += Math.pow(actual - predicted, 2);
    }
    const rSquared = ssTot > 0.001 ? Math.max(0, 1 - ssRes / ssTot) : 0.65;

    // Confidence formula
    let confidence = Math.round(
      Math.min(92, Math.max(25, 45 + rSquared * 40 + Math.min(10, n * 0.5)))
    );

    // Factors influencing
    if (slope > 0.015) {
      factorsInfluencing.push('Sustained upward congestion velocity');
    } else if (slope < -0.015) {
      factorsInfluencing.push('Dissipating crowd density trend');
    }

    if (densityDelta > 0.4) {
      factorsInfluencing.push('Progressive spatial density accumulation (+0.4 p/m²)');
    }

    if (speedDelta < -5) {
      factorsInfluencing.push('Systemic pedestrian deceleration');
    }

    if (factorsInfluencing.length === 0) {
      factorsInfluencing.push('Stable laminar throughput equilibrium');
    }

    // High variance / erratic pattern drops confidence
    const isLowConfidence = rSquared < 0.25 || n < 12;
    const lowConfidenceReason = isLowConfidence
      ? 'Erratic non-linear crowd turbulence detected; time-series variance exceeds certainty bounds.'
      : undefined;

    // Determine predicted state
    let state: PredictionState = 'NORMAL';
    if (projectedScore >= 0.65) {
      state = 'HIGH-RISK';
    } else if (projectedScore >= 0.35 || slope > 0.02) {
      state = 'INCREASING';
    } else {
      state = 'NORMAL';
    }

    // Projected curve points
    const projectedRiskCurve: { tOffset: number; risk: number }[] = [];
    for (let s = 0; s <= this.horizonSeconds; s += 10) {
      const frac = s / this.horizonSeconds;
      const interpolated =
        currentAnalysis.score + (projectedScore - currentAnalysis.score) * frac;
      projectedRiskCurve.push({
        tOffset: s,
        risk: Number(Math.max(0, Math.min(1, interpolated)).toFixed(3)),
      });
    }

    const historicalTrend = recent.map((r, idx) => ({
      time: r.timestamp,
      actualScore: r.score,
      predictedScore: Number((intercept + slope * idx).toFixed(3)),
    }));

    return {
      state,
      score: Number(projectedScore.toFixed(3)),
      confidence,
      horizonSeconds: this.horizonSeconds,
      isLowConfidence,
      lowConfidenceReason,
      factorsInfluencing,
      historicalTrend,
      projectedRiskCurve,
    };
  }
}
