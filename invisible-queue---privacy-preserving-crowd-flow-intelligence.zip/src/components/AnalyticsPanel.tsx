import React from 'react';
import { CrowdZone, TrackedPerson } from '../types';
import { FlowAnalysisResult } from '../analytics/flow';
import { 
  Users, 
  Gauge, 
  Clock, 
  ArrowDownRight, 
  ArrowUpRight, 
  MoveRight, 
  Compass, 
  Sliders
} from 'lucide-react';

interface AnalyticsPanelProps {
  tracks: TrackedPerson[];
  zones: CrowdZone[];
  flow: FlowAnalysisResult;
}

export const AnalyticsPanel: React.FC<AnalyticsPanelProps> = ({
  tracks,
  zones,
  flow,
}) => {
  const totalCount = tracks.length;
  const maxDensity = zones.length > 0 ? Math.max(...zones.map((z) => z.density)) : 0;
  const totalInflow = zones.reduce((acc, z) => acc + z.entryRate, 0);
  const totalOutflow = zones.reduce((acc, z) => acc + z.exitRate, 0);
  const avgDwell =
    totalCount > 0
      ? Number((tracks.reduce((acc, t) => acc + t.dwellTime, 0) / totalCount).toFixed(1))
      : 0;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Gauge className="w-4 h-4 text-cyan-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Real-Time Crowd Analytics
          </h2>
        </div>
        <span className="text-[11px] text-slate-400 font-mono">
          Sampling window: 60s continuous
        </span>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 mb-4">
        {/* Total People */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>People Count</span>
            <Users className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-xl font-black text-slate-100 font-mono">
            {totalCount}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Active anonymous tracks
          </div>
        </div>

        {/* Peak Density */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>Peak Density</span>
            <Gauge className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-400 font-mono">
            {maxDensity}{' '}
            <span className="text-xs text-slate-400 font-normal">p/m²</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Normative: &lt;1.5 p/m²
          </div>
        </div>

        {/* Inflow Rate */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>Inflow Rate</span>
            <ArrowDownRight className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl font-black text-emerald-400 font-mono">
            {totalInflow}{' '}
            <span className="text-xs text-slate-400 font-normal">/min</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Incoming pedestrians
          </div>
        </div>

        {/* Outflow Rate */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>Outflow Rate</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="text-xl font-black text-blue-400 font-mono">
            {totalOutflow}{' '}
            <span className="text-xs text-slate-400 font-normal">/min</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Egress pedestrians
          </div>
        </div>

        {/* Average Speed */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>Transit Speed</span>
            <MoveRight className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xl font-black text-indigo-400 font-mono">
            {flow.averageSpeed}{' '}
            <span className="text-xs text-slate-400 font-normal">px/s</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Cohesion: {Math.round(flow.flowCohesion * 100)}%
          </div>
        </div>

        {/* Average Dwell Time */}
        <div className="bg-slate-800/70 border border-slate-700/60 p-2.5 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
            <span>Avg Dwell Time</span>
            <Clock className="w-3.5 h-3.5 text-purple-400" />
          </div>
          <div className="text-xl font-black text-purple-400 font-mono">
            {avgDwell}{' '}
            <span className="text-xs text-slate-400 font-normal">s</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            In-scene duration
          </div>
        </div>
      </div>

      {/* Dynamic Zone Breakdown Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-800/80 text-[10px] uppercase tracking-wider text-slate-400 border-b border-slate-700/60">
            <tr>
              <th className="py-2 px-3">Zone</th>
              <th className="py-2 px-3">Count / Cap</th>
              <th className="py-2 px-3">Density (p/m²)</th>
              <th className="py-2 px-3">Inflow / Outflow</th>
              <th className="py-2 px-3">Net Balance</th>
              <th className="py-2 px-3">Avg Speed</th>
              <th className="py-2 px-3">Dwell</th>
              <th className="py-2 px-3">Dominant Flow</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {zones.map((zone) => {
              const occupancyPct = Math.round((zone.currentCount / zone.capacity) * 100);
              let occColor = 'bg-emerald-500';
              if (occupancyPct > 85) occColor = 'bg-rose-500';
              else if (occupancyPct > 60) occColor = 'bg-amber-500';

              return (
                <tr key={zone.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-semibold flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: zone.color }}
                    />
                    <span>{zone.name}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    <span>
                      {zone.currentCount} / {zone.capacity}
                    </span>
                    <div className="w-16 h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                      <div
                        className={`h-full ${occColor}`}
                        style={{ width: `${Math.min(100, occupancyPct)}%` }}
                      />
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    <span
                      className={
                        zone.density > 2.0
                          ? 'text-rose-400 font-bold'
                          : zone.density > 1.2
                          ? 'text-amber-400'
                          : 'text-slate-300'
                      }
                    >
                      {zone.density}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    <span className="text-emerald-400">+{zone.entryRate}</span>
                    <span className="text-slate-500"> / </span>
                    <span className="text-blue-400">-{zone.exitRate}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono">
                    <span
                      className={
                        zone.inflowOutflowBalance > 5
                          ? 'text-rose-400 font-bold'
                          : zone.inflowOutflowBalance > 0
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }
                    >
                      {zone.inflowOutflowBalance > 0 ? `+${zone.inflowOutflowBalance}` : zone.inflowOutflowBalance}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">
                    {zone.avgSpeed} px/s
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">
                    {zone.avgDwellTime}s
                  </td>
                  <td className="py-2.5 px-3 text-[11px] text-cyan-300 font-medium">
                    {zone.dominantDirection}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
