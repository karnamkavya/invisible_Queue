import { AnonymousTracker } from '../tracking/tracker';
import { DEFAULT_ZONES, ZoneAnalyzer, isPointInPolygon } from '../analytics/zones';
import { CongestionEngine } from '../analytics/congestion';
import { FlowAnalyzer } from '../analytics/flow';
import { EarlyCongestionPredictor } from '../prediction/predictor';
import { AnomalyDetector } from '../anomaly/detector';
import { SyntheticCrowdSimulator } from '../simulation/simulator';
import { Detection } from '../types';

export interface TestCaseResult {
  name: string;
  category: string;
  passed: boolean;
  message: string;
  durationMs: number;
}

export class AutomatedTestSuite {
  public static async runAllTests(): Promise<{
    passedCount: number;
    failedCount: number;
    totalCount: number;
    results: TestCaseResult[];
  }> {
    const results: TestCaseResult[] = [];

    // Test 1: Person Counting & Tracker Initialization
    {
      const start = performance.now();
      let passed = true;
      let message = 'Anonymous tracker assigns temporary IDs and counts persons correctly';
      try {
        const tracker = new AnonymousTracker();
        const dummyDetections: Detection[] = [
          {
            id: '1',
            bbox: { x: 50, y: 50, width: 25, height: 50 },
            confidence: 0.9,
            center: { x: 62.5, y: 75 },
            aspectRatio: 2.0,
          },
          {
            id: '2',
            bbox: { x: 150, y: 150, width: 25, height: 50 },
            confidence: 0.85,
            center: { x: 162.5, y: 175 },
            aspectRatio: 2.0,
          },
        ];
        const tracks = tracker.update(dummyDetections, 1000);
        if (tracks.length !== 2) {
          passed = false;
          message = `Expected 2 tracks, got ${tracks.length}`;
        }
        if (!tracks[0].trackId.startsWith('Person-')) {
          passed = false;
          message = `Expected anonymous Person-XX format, got ${tracks[0].trackId}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Person Detection & Anonymous Temporary IDs',
        category: 'Tracking',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 2: Zone Assignment via Polygon Intersection
    {
      const start = performance.now();
      let passed = true;
      let message = 'Ray-casting point-in-polygon correctly assigns tracks to Zone A';
      try {
        const zoneA = DEFAULT_ZONES[0];
        const pointInside = { x: 50, y: 100 };
        const pointOutside = { x: 500, y: 100 };
        const inside = isPointInPolygon(pointInside, zoneA.polygon);
        const outside = isPointInPolygon(pointOutside, zoneA.polygon);

        if (!inside || outside) {
          passed = false;
          message = `Polygon point containment failed: inside=${inside}, outside=${outside}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Zone Boundary Point-in-Polygon Logic',
        category: 'Analytics',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 3: Density Calculation Calibration
    {
      const start = performance.now();
      let passed = true;
      let message = 'Zone density accurately computes people per square meter';
      try {
        const analyzer = new ZoneAnalyzer(DEFAULT_ZONES);
        const tracker = new AnonymousTracker();
        // Place 10 detections inside Zone A
        const detections: Detection[] = Array.from({ length: 10 }, (_, i) => ({
          id: `det-${i}`,
          bbox: { x: 40 + i * 5, y: 100 + i * 5, width: 20, height: 40 },
          confidence: 0.9,
          center: { x: 50 + i * 5, y: 120 + i * 5 },
          aspectRatio: 2.0,
        }));
        const tracks = tracker.update(detections, 1000);
        const zones = analyzer.update(tracks, 1000);
        const zoneA = zones.find((z) => z.id === 'zone-a');

        if (!zoneA || zoneA.currentCount !== 10 || zoneA.density <= 0) {
          passed = false;
          message = `Zone A density calculation failed: count=${zoneA?.currentCount}, density=${zoneA?.density}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Zone Density Calibration',
        category: 'Analytics',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 4: Entry and Exit Rate Calculation
    {
      const start = performance.now();
      let passed = true;
      let message = 'Inflow / Outflow event window accurately tracks crossing rates';
      try {
        const analyzer = new ZoneAnalyzer(DEFAULT_ZONES);
        const tracker = new AnonymousTracker();

        // Frame 1: Person outside Zone B
        let dets: Detection[] = [
          {
            id: 'p1',
            bbox: { x: 50, y: 50, width: 20, height: 40 },
            confidence: 0.9,
            center: { x: 60, y: 70 },
            aspectRatio: 2.0,
          },
        ];
        let tracks = tracker.update(dets, 1000);
        analyzer.update(tracks, 1000);

        // Frame 2: Person moves into Zone B (x=220, y=150)
        dets = [
          {
            id: 'p1',
            bbox: { x: 210, y: 130, width: 20, height: 40 },
            confidence: 0.9,
            center: { x: 220, y: 150 },
            aspectRatio: 2.0,
          },
        ];
        tracks = tracker.update(dets, 2000);
        const zones = analyzer.update(tracks, 2000);
        const zoneB = zones.find((z) => z.id === 'zone-b');

        if (!zoneB || zoneB.entryRate < 1) {
          passed = false;
          message = `Expected Zone B entry rate >= 1, got ${zoneB?.entryRate}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Inflow & Outflow Rate Calculation',
        category: 'Analytics',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 5: Multi-Signal Congestion Engine Scoring
    {
      const start = performance.now();
      let passed = true;
      let message = 'Congestion engine integrates speed, conflict, and density without relying on density alone';
      try {
        const engine = new CongestionEngine();
        const flowAnalyzer = new FlowAnalyzer();
        const tracker = new AnonymousTracker();

        // Scenario: Low density, high speed => NORMAL
        const normalDets: Detection[] = [
          {
            id: '1',
            bbox: { x: 50, y: 50, width: 20, height: 40 },
            confidence: 0.9,
            center: { x: 60, y: 70 },
            aspectRatio: 2.0,
          },
        ];
        const tracks = tracker.update(normalDets, 1000);
        const flow = flowAnalyzer.analyze(tracks);
        const normalAnalysis = engine.evaluate(tracks, DEFAULT_ZONES, flow, 1000);

        if (normalAnalysis.state !== 'NORMAL') {
          passed = false;
          message = `Expected NORMAL, got ${normalAnalysis.state}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Multi-Signal Congestion State Classification',
        category: 'Congestion',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 6: Confidence Handling & Low-Confidence Suppression
    {
      const start = performance.now();
      let passed = true;
      let message = 'Low-confidence detections are suppressed to prevent phantom hallucinations';
      try {
        const tracker = new AnonymousTracker();
        const lowConfDets: Detection[] = [
          {
            id: 'low',
            bbox: { x: 100, y: 100, width: 20, height: 40 },
            confidence: 0.15, // Below 0.35 min threshold
            center: { x: 110, y: 120 },
            aspectRatio: 2.0,
          },
        ];
        const tracks = tracker.update(lowConfDets, 1000);
        if (tracks.length !== 0) {
          passed = false;
          message = `Expected low confidence detection to be suppressed, but track was created`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Low-Confidence Suppression & Robustness',
        category: 'Vision',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 7: Early Congestion Time-Series Prediction
    {
      const start = performance.now();
      let passed = true;
      let message = 'Predictor flags low confidence when history is insufficient or noisy';
      try {
        const predictor = new EarlyCongestionPredictor();
        const dummyAnalysis = {
          state: 'NORMAL' as const,
          score: 0.2,
          evidence: [],
          timestamp: Date.now(),
          contributingFactors: {
            densityContribution: 0.1,
            speedDecelerationContribution: 0.05,
            directionConflictContribution: 0.02,
            dwellTimeContribution: 0.02,
            inflowImbalanceContribution: 0.01,
          },
        };
        // Pass empty history to test low-confidence safeguard
        const prediction = predictor.predict(dummyAnalysis, []);
        if (!prediction.isLowConfidence) {
          passed = false;
          message = `Expected isLowConfidence=true for empty history`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Time-Series Prediction & Uncertainty Bounds',
        category: 'Prediction',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 8: Anomaly Detection Formulation
    {
      const start = performance.now();
      let passed = true;
      let message = 'Anomaly engine flags "Unusual movement pattern detected" on abrupt stops';
      try {
        const detector = new AnomalyDetector();
        // Simulate high opposing vector conflicts
        const mockFlow = {
          averageSpeed: 15,
          dominantAngleDeg: 45,
          dominantDirection: 'East',
          directionConflicts: [
            {
              location: { x: 200, y: 150 },
              trackIdA: 'Person-01',
              trackIdB: 'Person-02',
              conflictAngleDeg: 175,
              severity: 0.9,
            },
            {
              location: { x: 210, y: 160 },
              trackIdA: 'Person-03',
              trackIdB: 'Person-04',
              conflictAngleDeg: 168,
              severity: 0.85,
            },
            {
              location: { x: 220, y: 170 },
              trackIdA: 'Person-05',
              trackIdB: 'Person-06',
              conflictAngleDeg: 172,
              severity: 0.88,
            },
          ],
          conflictIndex: 0.85,
          suddenDirectionChangesCount: 0,
          flowCohesion: 0.3,
        };
        const anomalies = detector.detect([], DEFAULT_ZONES, mockFlow, 10000);
        if (anomalies.length === 0) {
          passed = false;
          message = 'Expected direction conflict anomaly to trigger';
        } else if (!anomalies[0].description.includes('Unusual movement pattern detected')) {
          passed = false;
          message = `Incorrect wording in anomaly description: ${anomalies[0].description}`;
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Anomaly Detection & Neutral Phrasing Verification',
        category: 'Anomaly',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 9: Synthetic Crowd Simulator Physics
    {
      const start = performance.now();
      let passed = true;
      let message = 'Simulator updates agent physics and respects entrance state';
      try {
        const sim = new SyntheticCrowdSimulator(640, 360, {
          agentCount: 15,
          entranceClosed: true,
        });
        const agents1 = sim.update(0.05);
        if (agents1.length === 0) {
          passed = false;
          message = 'Expected active simulated agents';
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Synthetic Crowd Agent Dynamics & Collision Avoidance',
        category: 'Simulation',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    // Test 10: Input File Validation Logic
    {
      const start = performance.now();
      let passed = true;
      let message = 'Rejects non-video or oversized (> 200MB) file types with descriptive user error';
      try {
        const dummyFile = new File(['dummy content'], 'document.pdf', {
          type: 'application/pdf',
        });
        const isValid =
          dummyFile.type.startsWith('video/') && dummyFile.size <= 200 * 1024 * 1024;
        if (isValid) {
          passed = false;
          message = 'PDF file should not be accepted as video';
        }
      } catch (err: any) {
        passed = false;
        message = err.message;
      }
      results.push({
        name: 'Video Input Validation & Guardrails',
        category: 'Vision',
        passed,
        message,
        durationMs: Number((performance.now() - start).toFixed(2)),
      });
    }

    const passedCount = results.filter((r) => r.passed).length;
    const failedCount = results.length - passedCount;

    return {
      passedCount,
      failedCount,
      totalCount: results.length,
      results,
    };
  }
}
