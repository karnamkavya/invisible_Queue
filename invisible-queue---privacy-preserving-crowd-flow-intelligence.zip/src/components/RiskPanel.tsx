import React from 'react';
import { CongestionAnalysis, EarlyPrediction } from '../types';
import { 
  AlertOctagon, 
  TrendingUp, 
  CheckCircle, 
  Hourglass, 
  Info, 
  Sparkles, 
  Clock, 
  ShieldAlert,
  ArrowRight
} from 'lucide-react';

interface RiskPanelProps {
  congestion: CongestionAnalysis;
  prediction: EarlyPrediction;
  onHorizonChange: (seconds: number) => void;
}

export const RiskPanel: React.FC<RiskPanelProps> = ({
  congestion,
  prediction,
  onHorizonChange,
}) => {
  // Congestion visual badge
  let badgeColor = 'bg-emerald-950/80 text-emerald-300 border-emerald-700';
  let badgeIcon = <CheckCircle className="w-5 h-5 text-emerald-400" />;
  if (congestion.state === 'HIGH-RISK CONGESTION') {
    badgeColor = 'bg-rose-950/90 text-rose-300 border-rose-600 animate-pulse';
    badgeIcon = <AlertOctagon className="w-5 h-5 text-rose-400" />;
  } else if (congestion.state === 'INCREASING') {
    badgeColor = 'bg-amber-950/90 text-amber-300 border-amber-600';
    badgeIcon = <TrendingUp className="w-5 h-5 text-amber-400" />;
  }

  // Prediction visual badge
  let predColor = 'text-emerald-400';
  if (prediction.state === 'HIGH-RISK') predColor = 'text-rose-400';
  else if (prediction.state === 'INCREASING') predColor = 'text-amber-400';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col gap-4">
      {/* 1. Real-Time Multi-Signal Congestion State */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Congestion State (Multi-Signal)
            </h2>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            Fused Index: <strong className="text-slate-100">{Math.round(congestion.score * 100)}%</strong>
          </span>
        </div>

        {/* State Banner */}
        <div className={`p-3 rounded-lg border flex items-center justify-between gap-3 ${badgeColor}`}>
          <div className="flex items-center gap-2.5">
            {badgeIcon}
            <div>
              <div className="text-sm font-black tracking-wide">
                {congestion.state}
              </div>
              <div className="text-[11px] opacity-90">
                Non-density-only composite fusion model
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-mono font-bold bg-slate-950/60 px-2 py-1 rounded">
              {(congestion.score * 100).toFixed(0)} / 100
            </span>
          </div>
        </div>

        {/* Diagnostic Evidence Breakdown (Requirement 8) */}
        <div className="mt-3">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wide mb-1.5 flex items-center gap-1">
            <Info className="w-3 h-3 text-cyan-400" />
            <span>Telemetry Evidence Behind State:</span>
          </div>
          <div className="space-y-1.5">
            {congestion.evidence.map((item, idx) => {
              let sevColor = 'bg-slate-800/80 border-slate-700/60 text-slate-300';
              if (item.severity === 'critical') {
                sevColor = 'bg-rose-950/40 border-rose-800/60 text-rose-200';
              } else if (item.severity === 'moderate') {
                sevColor = 'bg-amber-950/40 border-amber-800/60 text-amber-200';
              }

              return (
                <div
                  key={idx}
                  className={`px-2.5 py-1.5 rounded-lg border text-xs flex items-center justify-between gap-2 ${sevColor}`}
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="font-semibold text-slate-200">{item.factor}:</span>
                    <span className="truncate opacity-90">{item.description}</span>
                  </div>
                  <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-slate-900/80 shrink-0 font-bold">
                    {item.value}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <hr className="border-slate-800" />

      {/* 2. Early Congestion Time-Series Prediction (Requirement 9) */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Hourglass className="w-4 h-4 text-purple-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Early Congestion Prediction
            </h2>
          </div>

          {/* Horizon Selector */}
          <div className="flex items-center gap-1 bg-slate-800/80 p-0.5 rounded-md border border-slate-700 text-[10px]">
            {[30, 60, 120].map((sec) => (
              <button
                key={sec}
                onClick={() => onHorizonChange(sec)}
                className={`px-2 py-0.5 rounded font-mono transition-colors cursor-pointer ${
                  prediction.horizonSeconds === sec
                    ? 'bg-purple-600 text-white font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                +{sec}s
              </button>
            ))}
          </div>
        </div>

        {/* Prediction Status Card */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-[10px] text-slate-400 uppercase tracking-wide">
                Projected Horizon (+{prediction.horizonSeconds}s)
              </span>
              <div className={`text-base font-black tracking-wide ${predColor}`}>
                {prediction.state}
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase tracking-wide">
                Prediction Confidence
              </span>
              <div className="text-base font-bold font-mono text-slate-200">
                {prediction.confidence}%
              </div>
            </div>
          </div>

          {/* Confidence Meter Bar */}
          <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden mb-2.5">
            <div
              className={`h-full transition-all duration-500 ${
                prediction.confidence < 50
                  ? 'bg-amber-500'
                  : prediction.confidence < 75
                  ? 'bg-cyan-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${prediction.confidence}%` }}
            />
          </div>

          {/* Low Confidence Warning (Section 9 Requirement) */}
          {prediction.isLowConfidence ? (
            <div className="p-2 rounded bg-amber-950/60 border border-amber-800/70 text-amber-300 text-xs flex items-center gap-2 mb-2">
              <AlertOctagon className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>Prediction confidence is low.</strong> {prediction.lowConfidenceReason || 'High variance or limited sample window.'}
              </span>
            </div>
          ) : (
            <div className="text-[11px] text-slate-400 mb-2">
              Factors Influencing Prediction:
              <ul className="list-disc list-inside mt-1 text-slate-300 space-y-0.5">
                {prediction.factorsInfluencing.map((f, i) => (
                  <li key={i}>{f}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Mandatory Project Honesty Disclaimer (Section 9 & 31) */}
          <div className="text-[10px] text-slate-500 italic border-t border-slate-700/50 pt-1.5 mt-2">
            Disclaimer: Time-series projection based on recent rate of change. Never guarantees future crowd behavior.
          </div>
        </div>
      </div>
    </div>
  );
};
