import { BoundingBox, Detection, Point, TrackedPerson } from '../types';

export interface TrackerConfig {
  iouThreshold: number;
  maxLostFrames: number;
  minHitsToConfirm: number;
  maxHistoryPoints: number;
}

export const DEFAULT_TRACKER_CONFIG: TrackerConfig = {
  iouThreshold: 0.25,
  maxLostFrames: 30, // ~1 second persistence during temporary occlusion
  minHitsToConfirm: 2,
  maxHistoryPoints: 20,
};

function calculateIoU(boxA: BoundingBox, boxB: BoundingBox): number {
  const xA = Math.max(boxA.x, boxB.x);
  const yA = Math.max(boxA.y, boxB.y);
  const xB = Math.min(boxA.x + boxA.width, boxB.x + boxB.width);
  const yB = Math.min(boxA.y + boxA.height, boxB.y + boxB.height);

  const interWidth = Math.max(0, xB - xA);
  const interHeight = Math.max(0, yB - yA);
  const interArea = interWidth * interHeight;

  const boxAArea = boxA.width * boxA.height;
  const boxBArea = boxB.width * boxB.height;
  const unionArea = boxAArea + boxBArea - interArea;

  if (unionArea <= 0) return 0;
  return interArea / unionArea;
}

function euclideanDistance(p1: Point, p2: Point): number {
  return Math.hypot(p1.x - p2.x, p1.y - p2.y);
}

export class AnonymousTracker {
  private tracks: Map<string, TrackedPerson> = new Map();
  private nextId = 1;
  private config: TrackerConfig;
  public totalIdSwitches = 0;
  public activeTracksCount = 0;

  constructor(config: Partial<TrackerConfig> = {}) {
    this.config = { ...DEFAULT_TRACKER_CONFIG, ...config };
  }

  public reset(): void {
    this.tracks.clear();
    this.nextId = 1;
    this.totalIdSwitches = 0;
    this.activeTracksCount = 0;
  }

  public update(detections: Detection[], timestamp: number = Date.now()): TrackedPerson[] {
    const matchedDetections = new Set<number>();
    const matchedTracks = new Set<string>();

    // 1. Predict next position for active tracks based on velocity
    for (const [id, track] of this.tracks.entries()) {
      if (track.lostFrames > 0) {
        // Project position linearly
        const projectedPos: Point = {
          x: track.currentPos.x + track.velocity.x * (1 / 30),
          y: track.currentPos.y + track.velocity.y * (1 / 30),
        };
        track.currentPos = projectedPos;
        track.bbox.x = projectedPos.x - track.bbox.width / 2;
        track.bbox.y = projectedPos.y - track.bbox.height / 2;
      }
    }

    // 2. Associate detections with existing tracks using IoU & center distance
    const trackEntries = Array.from(this.tracks.entries());
    const costMatrix: { trackIdx: number; detIdx: number; score: number }[] = [];

    for (let t = 0; t < trackEntries.length; t++) {
      const [_, track] = trackEntries[t];
      for (let d = 0; d < detections.length; d++) {
        const det = detections[d];
        const iou = calculateIoU(track.bbox, det.bbox);
        const dist = euclideanDistance(track.currentPos, det.center);
        // Hybrid matching score: higher IoU, lower distance
        const normalizedDist = Math.max(0, 1 - dist / (track.bbox.height * 1.5 || 60));
        const combinedScore = iou * 0.7 + normalizedDist * 0.3;

        if (iou > this.config.iouThreshold || normalizedDist > 0.45) {
          costMatrix.push({ trackIdx: t, detIdx: d, score: combinedScore });
        }
      }
    }

    // Sort descending by score (greedy bipartite matching)
    costMatrix.sort((a, b) => b.score - a.score);

    for (const match of costMatrix) {
      const { trackIdx, detIdx, score } = match;
      const [trackId, track] = trackEntries[trackIdx];

      if (matchedTracks.has(trackId) || matchedDetections.has(detIdx)) {
        continue;
      }

      matchedTracks.add(trackId);
      matchedDetections.add(detIdx);

      const det = detections[detIdx];
      const dt = Math.max(0.016, (timestamp - track.lastSeen) / 1000);

      // Compute velocity vector
      const vx = (det.center.x - track.currentPos.x) / dt;
      const vy = (det.center.y - track.currentPos.y) / dt;
      // Exponential moving average for velocity smoothing
      const smoothedVx = track.velocity.x * 0.4 + vx * 0.6;
      const smoothedVy = track.velocity.y * 0.4 + vy * 0.6;
      const speed = Math.hypot(smoothedVx, smoothedVy);
      const angle = Math.atan2(smoothedVy, smoothedVx);

      // Update track
      track.previousPos = { ...track.currentPos };
      track.currentPos = { ...det.center };
      track.bbox = { ...det.bbox };
      track.velocity = { x: smoothedVx, y: smoothedVy };
      track.speed = speed;
      track.angle = angle;
      track.lastSeen = timestamp;
      track.lostFrames = 0;
      track.isOccluded = false;
      // Smooth tracking confidence
      track.confidence = Math.min(0.99, track.confidence * 0.7 + det.confidence * 0.3);
      track.dwellTime = (timestamp - track.firstSeen) / 1000;

      // Update history trajectory
      track.history.push({ ...det.center });
      if (track.history.length > this.config.maxHistoryPoints) {
        track.history.shift();
      }
    }

    // 3. Mark unmatched tracks as lost or occluded
    for (const [trackId, track] of this.tracks.entries()) {
      if (!matchedTracks.has(trackId)) {
        track.lostFrames += 1;
        track.isOccluded = track.lostFrames <= this.config.maxLostFrames;
        // Decay confidence during lost period
        track.confidence = Math.max(0.2, track.confidence * 0.95);

        // If exceeded maximum grace period, remove track permanently
        if (track.lostFrames > this.config.maxLostFrames) {
          this.tracks.delete(trackId);
        }
      }
    }

    // 4. Create new temporary tracks for unmatched detections
    for (let d = 0; d < detections.length; d++) {
      if (!matchedDetections.has(d)) {
        const det = detections[d];
        // Only initialize if detection confidence meets minimum threshold
        if (det.confidence >= 0.35) {
          const trackId = `Person-${String(this.nextId++).padStart(2, '0')}`;
          const newTrack: TrackedPerson = {
            trackId,
            firstSeen: timestamp,
            lastSeen: timestamp,
            bbox: { ...det.bbox },
            currentPos: { ...det.center },
            previousPos: { ...det.center },
            velocity: { x: 0, y: 0 },
            speed: 0,
            angle: 0,
            confidence: det.confidence,
            history: [{ ...det.center }],
            zoneId: null,
            dwellTime: 0,
            isOccluded: false,
            lostFrames: 0,
          };
          this.tracks.set(trackId, newTrack);
        }
      }
    }

    this.activeTracksCount = this.tracks.size;
    // Return visible tracks (filter out tracks lost for too many frames)
    return Array.from(this.tracks.values()).filter(t => t.lostFrames < 8);
  }

  public getTracks(): TrackedPerson[] {
    return Array.from(this.tracks.values());
  }
}
