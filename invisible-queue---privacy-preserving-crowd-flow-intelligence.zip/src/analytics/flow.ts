import { Point, TrackedPerson } from '../types';

export interface FlowConflict {
  location: Point;
  trackIdA: string;
  trackIdB: string;
  conflictAngleDeg: number;
  severity: number; // 0.0 - 1.0
}

export interface FlowAnalysisResult {
  averageSpeed: number; // px/s
  dominantAngleDeg: number;
  dominantDirection: string;
  directionConflicts: FlowConflict[];
  conflictIndex: number; // 0.0 - 1.0 overall collision risk
  suddenDirectionChangesCount: number;
  flowCohesion: number; // 0.0 (random chaos) to 1.0 (smooth uniform laminar flow)
}

export class FlowAnalyzer {
  private prevSpeeds: Map<string, number> = new Map();
  private prevAngles: Map<string, number> = new Map();

  public analyze(tracks: TrackedPerson[], proximityThreshold: number = 60): FlowAnalysisResult {
    if (tracks.length === 0) {
      return {
        averageSpeed: 0,
        dominantAngleDeg: 0,
        dominantDirection: 'None',
        directionConflicts: [],
        conflictIndex: 0,
        suddenDirectionChangesCount: 0,
        flowCohesion: 1.0,
      };
    }

    let totalSpeed = 0;
    let sumVx = 0;
    let sumVy = 0;
    let suddenChanges = 0;

    // 1. Process individual tracks
    for (const track of tracks) {
      totalSpeed += track.speed;
      if (track.speed > 0.5) {
        sumVx += Math.cos(track.angle);
        sumVy += Math.sin(track.angle);
      }

      // Check sudden direction change > 90 deg (1.57 rad)
      const prevAngle = this.prevAngles.get(track.trackId);
      if (prevAngle !== undefined && track.speed > 5) {
        let diff = Math.abs(track.angle - prevAngle);
        if (diff > Math.PI) diff = 2 * Math.PI - diff;
        if (diff > Math.PI / 2) {
          suddenChanges++;
        }
      }
      this.prevAngles.set(track.trackId, track.angle);
      this.prevSpeeds.set(track.trackId, track.speed);
    }

    const averageSpeed = totalSpeed / tracks.length;

    // Cohesion: vector sum magnitude divided by number of moving tracks
    const movingCount = tracks.filter((t) => t.speed > 0.5).length;
    let flowCohesion = 1.0;
    let dominantAngleDeg = 0;
    let dominantDirection = 'Stationary';

    if (movingCount > 0) {
      const meanVx = sumVx / movingCount;
      const meanVy = sumVy / movingCount;
      flowCohesion = Math.min(1.0, Math.hypot(meanVx, meanVy));
      const rad = Math.atan2(meanVy, meanVx);
      let deg = ((rad * 180) / Math.PI) % 360;
      if (deg < 0) deg += 360;
      dominantAngleDeg = Math.round(deg);

      if (deg >= 337.5 || deg < 22.5) dominantDirection = 'East (→)';
      else if (deg >= 22.5 && deg < 67.5) dominantDirection = 'South-East (↘)';
      else if (deg >= 67.5 && deg < 112.5) dominantDirection = 'South (↓)';
      else if (deg >= 112.5 && deg < 157.5) dominantDirection = 'South-West (↙)';
      else if (deg >= 157.5 && deg < 202.5) dominantDirection = 'West (←)';
      else if (deg >= 202.5 && deg < 247.5) dominantDirection = 'North-West (↖)';
      else if (deg >= 247.5 && deg < 292.5) dominantDirection = 'North (↑)';
      else dominantDirection = 'North-East (↗)';
    }

    // 2. Identify directional conflicts between proximate persons
    const conflicts: FlowConflict[] = [];
    for (let i = 0; i < tracks.length; i++) {
      const a = tracks[i];
      if (a.speed < 4) continue; // Ignore nearly stationary people

      for (let j = i + 1; j < tracks.length; j++) {
        const b = tracks[j];
        if (b.speed < 4) continue;

        const dist = Math.hypot(a.currentPos.x - b.currentPos.x, a.currentPos.y - b.currentPos.y);
        if (dist <= proximityThreshold) {
          // Dot product of velocity directions
          const dot =
            Math.cos(a.angle) * Math.cos(b.angle) + Math.sin(a.angle) * Math.sin(b.angle);

          // If dot < -0.4, flows are opposing / counter-current
          if (dot < -0.35) {
            let angleDiff = Math.acos(Math.max(-1, Math.min(1, dot))) * (180 / Math.PI);
            const severity = Math.min(1.0, (1 - (dot + 1) / 2) * (1 - dist / proximityThreshold));

            conflicts.push({
              location: {
                x: (a.currentPos.x + b.currentPos.x) / 2,
                y: (a.currentPos.y + b.currentPos.y) / 2,
              },
              trackIdA: a.trackId,
              trackIdB: b.trackId,
              conflictAngleDeg: Math.round(angleDiff),
              severity: Number(severity.toFixed(2)),
            });
          }
        }
      }
    }

    // Overall conflict index
    const conflictIndex = Math.min(
      1.0,
      conflicts.reduce((acc, c) => acc + c.severity, 0) / Math.max(1, tracks.length * 0.4)
    );

    return {
      averageSpeed: Number(averageSpeed.toFixed(1)),
      dominantAngleDeg,
      dominantDirection,
      directionConflicts: conflicts.slice(0, 10), // keep top 10 for display
      conflictIndex: Number(conflictIndex.toFixed(2)),
      suddenDirectionChangesCount: suddenChanges,
      flowCohesion: Number(flowCohesion.toFixed(2)),
    };
  }
}
