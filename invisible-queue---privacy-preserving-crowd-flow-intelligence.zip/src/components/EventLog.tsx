import React from 'react';
import { SystemEventLog } from '../types';
import { History, ShieldCheck, Download, Trash2 } from 'lucide-react';

interface EventLogProps {
  logs: SystemEventLog[];
  onClear: () => void;
}

export const EventLog: React.FC<EventLogProps> = ({ logs, onClear }) => {
  const exportLogsAsCSV = () => {
    if (logs.length === 0) return;
    const headers = ['Timestamp', 'Type', 'Zone', 'Event', 'Confidence', 'Recommendation'];
    const rows = logs.map((l) => [
      new Date(l.timestamp).toISOString(),
      l.type,
      l.zone,
      `"${l.event.replace(/"/g, '""')}"`,
      `${Math.round(l.confidence * 100)}%`,
      `"${(l.recommendation || '').replace(/"/g, '""')}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `invisible_queue_audit_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl">
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-cyan-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            System Event & Audit Log
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={exportLogsAsCSV}
            disabled={logs.length === 0}
            className="text-[11px] text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded border border-slate-700 flex items-center gap-1 cursor-pointer disabled:opacity-40"
            title="Export CSV log"
          >
            <Download className="w-3 h-3 text-cyan-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={onClear}
            disabled={logs.length === 0}
            className="text-[11px] text-slate-400 hover:text-slate-200 p-1 cursor-pointer disabled:opacity-40"
            title="Clear logs"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="overflow-x-auto max-h-56">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-800/80 text-[10px] uppercase tracking-wider text-slate-400 border-b border-slate-700/60 sticky top-0">
            <tr>
              <th className="py-2 px-3">Time</th>
              <th className="py-2 px-3">Category</th>
              <th className="py-2 px-3">Zone</th>
              <th className="py-2 px-3">Event Detail</th>
              <th className="py-2 px-3">Conf</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {logs.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-6 text-center text-slate-500">
                  No logged events in current session.
                </td>
              </tr>
            ) : (
              logs.map((log) => {
                const timeStr = new Date(log.timestamp).toLocaleTimeString();
                let catBadge = 'text-slate-400 bg-slate-800';
                if (log.type === 'CONGESTION_CHANGE') {
                  catBadge = 'text-rose-300 bg-rose-950/80 border border-rose-800';
                } else if (log.type === 'ANOMALY_DETECTED') {
                  catBadge = 'text-amber-300 bg-amber-950/80 border border-amber-800';
                } else if (log.type === 'PRIVACY_AUDIT') {
                  catBadge = 'text-emerald-300 bg-emerald-950/80 border border-emerald-800';
                }

                return (
                  <tr key={log.id} className="hover:bg-slate-800/40 font-mono text-[11px]">
                    <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{timeStr}</td>
                    <td className="py-2 px-3">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] ${catBadge}`}>
                        {log.type}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-cyan-300">{log.zone}</td>
                    <td className="py-2 px-3 font-sans text-slate-200">{log.event}</td>
                    <td className="py-2 px-3 text-slate-400">
                      {Math.round(log.confidence * 100)}%
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center gap-1.5 text-[10px] text-slate-500 border-t border-slate-800 pt-2 mt-2">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
        <span>Audit Guarantee: Zero biometric signatures or personal identifying fields recorded in log storage.</span>
      </div>
    </div>
  );
};
