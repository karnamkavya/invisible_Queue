import React from 'react';
import { 
  ShieldCheck, 
  Play, 
  Sparkles, 
  FlaskConical, 
  CheckCircle2, 
  FileText, 
  SlidersHorizontal,
  Share2,
  Activity,
  Layers
} from 'lucide-react';

interface HeaderProps {
  fps: number;
  latencyMs: number;
  environment: string;
  onEnvironmentChange: (env: string) => void;
  onStartDemo: () => void;
  onOpenPresentation: () => void;
  onOpenWhatIf: () => void;
  onOpenEvaluation: () => void;
  onOpenTests: () => void;
  onOpenDocs: () => void;
  onOpenPrivacy: () => void;
  activeScenarioName: string;
}

export const Header: React.FC<HeaderProps> = ({
  fps,
  latencyMs,
  environment,
  onEnvironmentChange,
  onStartDemo,
  onOpenPresentation,
  onOpenWhatIf,
  onOpenEvaluation,
  onOpenTests,
  onOpenDocs,
  onOpenPrivacy,
  activeScenarioName,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 px-4 py-3 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo & Branding */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Layers className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black tracking-wider uppercase bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-sky-200 to-indigo-300">
                Invisible Queue
              </h1>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800/80 rounded-full tracking-wide">
                CV-FLOW v1.0
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Privacy-Preserving Crowd Flow Intelligence • No Face Recognition
            </p>
          </div>
        </div>

        {/* Telemetry & Privacy Pill */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Environment Selector */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700/60">
            <span className="text-slate-400">Venue:</span>
            <select
              value={environment}
              onChange={(e) => onEnvironmentChange(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-none cursor-pointer text-xs"
            >
              <option value="Central Railway Concourse" className="bg-slate-900">Transit Station (Concourse)</option>
              <option value="Airport Departure Gate 4" className="bg-slate-900">Airport Terminal Gate</option>
              <option value="Stadium South Exit Plaza" className="bg-slate-900">Stadium Exit Plaza</option>
              <option value="University Science Hallway" className="bg-slate-900">University Corridor</option>
              <option value="Shopping Mall Food Court" className="bg-slate-900">Commercial Mall Atrium</option>
            </select>
          </div>

          {/* Performance Pill */}
          <div className="flex items-center gap-2 bg-slate-800/80 px-2.5 py-1.5 rounded-lg border border-slate-700/60 font-mono text-[11px]">
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-slate-300"><span className="text-emerald-400 font-bold">{fps}</span> FPS</span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300"><span className="text-cyan-400 font-bold">{latencyMs}</span> ms</span>
          </div>

          {/* Privacy Verification Pill */}
          <button
            onClick={onOpenPrivacy}
            className="flex items-center gap-1.5 bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 px-2.5 py-1.5 rounded-lg border border-emerald-800/70 transition-colors cursor-pointer"
            title="Open Privacy Audit & Configuration"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold text-[11px]">100% Privacy Verified</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Start Demo Button */}
          <button
            onClick={onStartDemo}
            className="flex items-center gap-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs shadow-md shadow-cyan-600/30 transition-all cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>START DEMO</span>
          </button>

          {/* What-If Simulator */}
          <button
            onClick={onOpenWhatIf}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
            title="Simulate queue mitigations"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">What-If</span>
          </button>

          {/* LinkedIn Presentation */}
          <button
            onClick={onOpenPresentation}
            className="flex items-center gap-1 bg-indigo-950/70 hover:bg-indigo-900/80 text-indigo-300 px-2.5 py-1.5 rounded-lg border border-indigo-800/80 text-xs font-medium transition-colors cursor-pointer"
            title="10-step guided demo for presentations and LinkedIn"
          >
            <Share2 className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Showcase</span>
          </button>

          {/* Evaluation */}
          <button
            onClick={onOpenEvaluation}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
            title="System evaluation benchmarks"
          >
            <FlaskConical className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">Evaluation</span>
          </button>

          {/* Test Suite */}
          <button
            onClick={onOpenTests}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
            title="Run automated unit test suite"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Tests</span>
          </button>

          {/* Docs */}
          <button
            onClick={onOpenDocs}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1.5 rounded-lg border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
            title="View system documentation and script"
          >
            <FileText className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Docs</span>
          </button>
        </div>
      </div>
    </header>
  );
};
