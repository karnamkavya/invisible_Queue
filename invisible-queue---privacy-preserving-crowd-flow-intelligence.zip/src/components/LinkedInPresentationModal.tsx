import React, { useState } from 'react';
import { PRESENTATION_STEPS, PresentationStep } from '../docs/documentation';
import { DemoScenarioType } from '../types';
import { 
  Share2, 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Mic, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  Cpu, 
  Activity, 
  Eye, 
  Layers, 
  Hourglass, 
  SlidersHorizontal 
} from 'lucide-react';

interface LinkedInPresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerScenario: (scenario: DemoScenarioType) => void;
}

export const LinkedInPresentationModal: React.FC<LinkedInPresentationModalProps> = ({
  isOpen,
  onClose,
  onTriggerScenario,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isOpen) return null;

  const currentStep = PRESENTATION_STEPS[currentStepIndex];
  const isFinalSlide = currentStepIndex === PRESENTATION_STEPS.length - 1;

  const goToNext = () => {
    if (currentStepIndex < PRESENTATION_STEPS.length - 1) {
      const nextIdx = currentStepIndex + 1;
      setCurrentStepIndex(nextIdx);
      onTriggerScenario(PRESENTATION_STEPS[nextIdx].scenario);
    }
  };

  const goToPrev = () => {
    if (currentStepIndex > 0) {
      const prevIdx = currentStepIndex - 1;
      setCurrentStepIndex(prevIdx);
      onTriggerScenario(PRESENTATION_STEPS[prevIdx].scenario);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-slate-900 px-5 py-3.5 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
              <Share2 className="w-4 h-4 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-100">
                LinkedIn & College Showcase Mode
              </h2>
              <p className="text-xs text-indigo-300">
                Guided 10-Step Interactive Demonstration Walkthrough
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Stepper Bar */}
        <div className="bg-slate-950 px-5 py-2.5 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            {PRESENTATION_STEPS.map((s, idx) => (
              <button
                key={s.step}
                onClick={() => {
                  setCurrentStepIndex(idx);
                  onTriggerScenario(s.scenario);
                }}
                className={`w-6 h-6 rounded-full text-[11px] font-bold flex items-center justify-center transition-all cursor-pointer ${
                  currentStepIndex === idx
                    ? 'bg-indigo-600 text-white ring-2 ring-indigo-400'
                    : idx < currentStepIndex
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-700'
                    : 'bg-slate-800 text-slate-500'
                }`}
              >
                {s.step}
              </button>
            ))}
          </div>
          <span className="text-slate-400 font-mono text-[11px] shrink-0 ml-2">
            Step {currentStepIndex + 1} / {PRESENTATION_STEPS.length}
          </span>
        </div>

        {/* Main Step Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Step Title & Trigger Tag */}
          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <h3 className="text-base font-black text-slate-100">
              {currentStep.title}
            </h3>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 shrink-0">
              Scenario: {currentStep.scenario}
            </span>
          </div>

          {/* Narrative Explanation */}
          <div className="bg-slate-800/70 border border-slate-700/80 rounded-xl p-4">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Demonstration Objective:
            </div>
            <p className="text-xs text-slate-200 leading-relaxed">
              {currentStep.narrative}
            </p>
          </div>

          {/* Suggested Voiceover / Script Notes */}
          <div className="bg-indigo-950/40 border border-indigo-800/70 rounded-xl p-4">
            <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 mb-1.5">
              <Mic className="w-4 h-4 text-indigo-400" />
              <span>Suggested 30-Second Speaker Script:</span>
            </div>
            <p className="text-xs text-indigo-100 italic leading-relaxed">
              {currentStep.suggestedVoiceover}
            </p>
          </div>

          {/* Concluding Final Slide (Section 32 Requirement) */}
          {isFinalSlide && (
            <div className="bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-950 border-2 border-indigo-500/80 rounded-2xl p-6 text-center shadow-xl space-y-4">
              <div className="inline-block px-3 py-1 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-700 text-xs font-bold tracking-wider uppercase mb-1">
                Project Conclusion & Capstone Slide
              </div>
              <h2 className="text-xl font-black tracking-tight text-white">
                Privacy-Preserving Crowd Flow Intelligence
              </h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-w-lg mx-auto text-xs font-semibold">
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-cyan-300 flex items-center justify-center gap-1.5">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span>AI</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-sky-300 flex items-center justify-center gap-1.5">
                  <Eye className="w-4 h-4 text-sky-400" />
                  <span>Computer Vision</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-purple-300 flex items-center justify-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-400" />
                  <span>Anonymous Tracking</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-amber-300 flex items-center justify-center gap-1.5">
                  <Hourglass className="w-4 h-4 text-amber-400" />
                  <span>Prediction</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-emerald-300 flex items-center justify-center gap-1.5">
                  <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
                  <span>Simulation</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-800/90 border border-slate-700 text-rose-300 flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-rose-400" />
                  <span>Privacy</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 max-w-md mx-auto italic">
                Demonstrated without exaggerated claims: real-time spatial crowd intelligence that respects civil privacy without sacrificing public safety.
              </p>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="bg-slate-800/90 px-5 py-3 border-t border-slate-700 flex items-center justify-between">
          <button
            onClick={goToPrev}
            disabled={currentStepIndex === 0}
            className="px-3.5 py-1.5 rounded-lg border border-slate-600 text-xs font-medium text-slate-300 hover:bg-slate-700 cursor-pointer disabled:opacity-40 flex items-center gap-1"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous Step</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg border border-slate-600 text-xs text-slate-300 hover:bg-slate-700 cursor-pointer"
            >
              Exit Showcase
            </button>
            <button
              onClick={isFinalSlide ? onClose : goToNext}
              className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 cursor-pointer flex items-center gap-1"
            >
              <span>{isFinalSlide ? 'Finish Showcase' : 'Next Step'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
