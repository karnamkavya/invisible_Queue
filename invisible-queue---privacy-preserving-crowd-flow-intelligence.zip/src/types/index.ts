/**
 * Core Domain Types for Invisible Queue
 * Privacy-Preserving Crowd Flow Intelligence
 */

export interface Point {
  x: number;
  y: number;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Detection {
  id: string; // temporary detection id
  bbox: BoundingBox;
  confidence: number;
  center: Point;
  aspectRatio: number;
}

export interface TrackedPerson {
  trackId: string; // Anonymous temporary ID: e.g. "Person-01"
  firstSeen: number; // timestamp
  lastSeen: number;
  bbox: BoundingBox;
  currentPos: Point;
  previousPos: Point;
  velocity: Point; // px/s or normalized units/s
  speed: number;
  angle: number; // radians
  confidence: number;
  history: Point[]; // last N positions for flow trajectory
  zoneId: string | null;
  dwellTime: number; // seconds in scene
  isOccluded: boolean;
  lostFrames: number;
}

export interface CrowdZone {
  id: string;
  name: string;
  color: string;
  polygon: Point[]; // normalized 0-1 coordinates or pixel space
  capacity: number;
  // Live calculated metrics:
  currentCount: number;
  density: number; // people per m² (estimated based on normalized area)
  entryRate: number; // people per minute
  exitRate: number; // people per minute
  avgDwellTime: number; // seconds
  avgSpeed: number; // px/s or m/s
  dominantDirection: string; // "North-East (45°)", "West (180°)", etc.
  dominantVector: Point;
  inflowOutflowBalance: number; // net difference: positive = accumulation
  isRestricted?: boolean;
}

export type CongestionState = 'NORMAL' | 'INCREASING' | 'HIGH-RISK CONGESTION';

export interface CongestionEvidence {
  factor: string;
  description: string;
  severity: 'low' | 'moderate' | 'critical';
  value: string;
}

export interface CongestionAnalysis {
  state: CongestionState;
  score: number; // 0.0 - 1.0
  evidence: CongestionEvidence[];
  timestamp: number;
  contributingFactors: {
    densityContribution: number;
    speedDecelerationContribution: number;
    directionConflictContribution: number;
    dwellTimeContribution: number;
    inflowImbalanceContribution: number;
  };
}

export type PredictionState = 'NORMAL' | 'INCREASING' | 'HIGH-RISK';

export interface EarlyPrediction {
  state: PredictionState;
  score: number; // 0.0 - 1.0
  confidence: number; // 0 - 100%
  horizonSeconds: number; // 30, 60, 120
  isLowConfidence: boolean;
  lowConfidenceReason?: string;
  factorsInfluencing: string[];
  historicalTrend: { time: number; actualScore: number; predictedScore: number }[];
  projectedRiskCurve: { tOffset: number; risk: number }[];
}

export interface AnomalyEvent {
  id: string;
  timestamp: number;
  zoneId: string;
  zoneName: string;
  patternType: 
    | 'Sudden Crowd Movement'
    | 'Sudden Density Surge'
    | 'Abnormal Direction Conflict'
    | 'Unexpected Mass Stopping'
    | 'Inflow Wave Spike';
  confidence: number;
  supportingMeasurements: {
    speedDelta?: number;
    densityDelta?: number;
    conflictAngle?: number;
    accelerationRate?: number;
    dwellSpike?: number;
  };
  description: string;
}

export interface OperationalRecommendation {
  id: string;
  timestamp: number;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  action: string;
  detail: string;
  targetZone: string;
  expectedImpact: string;
  isAiGenerated: true; // Mandatory badge
}

export interface WhatIfScenarioState {
  entranceClosed: boolean;
  alternatePathOpen: boolean;
  zoneRestricted: boolean;
  pathwayCapacityMultiplier: number; // 0.5 - 2.0
  incomingFlowMultiplier: number; // 0.5 - 2.5
  // Output simulated metrics:
  simulatedRisk: number;
  simulatedState: CongestionState;
  zoneDensityShift: Record<string, number>; // % change
  estimatedClearanceTimeSeconds: number;
}

export type VideoSourceType = 'synthetic' | 'webcam' | 'uploaded' | 'sample-recorded';

export type DemoScenarioType = 
  | 'NORMAL_FLOW'
  | 'GRADUAL_CONGESTION'
  | 'HIGH_CONGESTION'
  | 'SUDDEN_CROWD_MOVEMENT'
  | 'OVERLAPPING_PEOPLE'
  | 'LOW_LIGHT';

export interface PrivacyConfig {
  blurLevel: 'none' | 'blur-boxes' | 'silhouette' | 'heatmap-only';
  strictTemporaryIds: boolean; // expire in <= 3 seconds
  zeroRawFootageStorage: boolean;
  biometricsDisabled: boolean;
  metadataOnlyLogging: boolean;
}

export interface RobustnessWarnings {
  isLowLight: boolean;
  lowLightValue: number; // 0 - 255 avg luminance
  isCameraShaking: boolean;
  shakeMagnitude: number;
  isHighOcclusion: boolean;
  occlusionRatio: number;
  trackingConfidenceDrop: boolean;
  averageConfidence: number;
}

export interface BenchmarkMetrics {
  detectionPrecision: number;
  detectionRecall: number;
  trackingStabilityHOTA: number;
  idSwitchRatePerMin: number;
  averageFPS: number;
  processingLatencyMs: number;
  congestionClassificationAccuracy: number;
  falseAlertRatePercent: number;
  predictionRMSE_60s: number;
  evaluatedAt: string | null;
  isEvaluated: boolean;
}

export interface SystemEventLog {
  id: string;
  timestamp: number;
  zone: string;
  type: 'CONGESTION_CHANGE' | 'ANOMALY_DETECTED' | 'RECOMMENDATION_ISSUED' | 'PRIVACY_AUDIT' | 'WARNING';
  event: string;
  confidence: number;
  recommendation?: string;
}
