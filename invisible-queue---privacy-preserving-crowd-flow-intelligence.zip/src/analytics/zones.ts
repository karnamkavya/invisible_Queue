import { CrowdZone, Point, TrackedPerson } from '../types';

/**
 * Standard default zones across a 640x360 perspective view:
 * Zone A: North Entrance (Left/Inflow)
 * Zone B: Bottleneck Corridor (Center-West)
 * Zone C: Central Concourse (Center-East)
 * Zone D: South Exit (Right/Outflow)
 */
export const DEFAULT_ZONES: CrowdZone[] = [
  {
    id: 'zone-a',
    name: 'Zone A (North Entrance)',
    color: '#3b82f6', // blue
    polygon: [
      { x: 20, y: 30 },
      { x: 170, y: 30 },
      { x: 170, y: 330 },
      { x: 20, y: 330 },
    ],
    capacity: 25,
    currentCount: 0,
    density: 0,
    entryRate: 0,
    exitRate: 0,
    avgDwellTime: 0,
    avgSpeed: 0,
    dominantDirection: 'East (→)',
    dominantVector: { x: 1, y: 0 },
    inflowOutflowBalance: 0,
  },
  {
    id: 'zone-b',
    name: 'Zone B (Bottleneck Corridor)',
    color: '#f59e0b', // amber
    polygon: [
      { x: 180, y: 80 },
      { x: 310, y: 80 },
      { x: 310, y: 280 },
      { x: 180, y: 280 },
    ],
    capacity: 18,
    currentCount: 0,
    density: 0,
    entryRate: 0,
    exitRate: 0,
    avgDwellTime: 0,
    avgSpeed: 0,
    dominantDirection: 'East (→)',
    dominantVector: { x: 1, y: 0 },
    inflowOutflowBalance: 0,
  },
  {
    id: 'zone-c',
    name: 'Zone C (Central Concourse)',
    color: '#8b5cf6', // purple
    polygon: [
      { x: 320, y: 30 },
      { x: 470, y: 30 },
      { x: 470, y: 330 },
      { x: 320, y: 330 },
    ],
    capacity: 35,
    currentCount: 0,
    density: 0,
    entryRate: 0,
    exitRate: 0,
    avgDwellTime: 0,
    avgSpeed: 0,
    dominantDirection: 'East (→)',
    dominantVector: { x: 1, y: 0 },
    inflowOutflowBalance: 0,
  },
  {
    id: 'zone-d',
    name: 'Zone D (South Exit)',
    color: '#10b981', // emerald
    polygon: [
      { x: 480, y: 30 },
      { x: 620, y: 30 },
      { x: 620, y: 330 },
      { x: 480, y: 330 },
    ],
    capacity: 30,
    currentCount: 0,
    density: 0,
    entryRate: 0,
    exitRate: 0,
    avgDwellTime: 0,
    avgSpeed: 0,
    dominantDirection: 'East (→)',
    dominantVector: { x: 1, y: 0 },
    inflowOutflowBalance: 0,
  },
];

/**
 * Standard ray-casting algorithm to test if a point is inside a polygon
 */
export function isPointInPolygon(point: Point, polygon: Point[]): boolean {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i].x;
    const yi = polygon[i].y;
    const xj = polygon[j].x;
    const yj = polygon[j].y;

    const intersect =
      yi > point.y !== yj > point.y &&
      point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

/**
 * Computes polygon area in pixel² (Shoelace formula)
 */
export function getPolygonArea(polygon: Point[]): number {
  let area = 0;
  const n = polygon.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    area += polygon[i].x * polygon[j].y;
    area -= polygon[j].x * polygon[i].y;
  }
  return Math.abs(area) / 2;
}

/**
 * Converts radian angle to friendly compass direction string
 */
export function angleToDirectionString(rad: number): string {
  // Normalize to 0 - 2PI
  let deg = ((rad * 180) / Math.PI) % 360;
  if (deg < 0) deg += 360;

  if (deg >= 337.5 || deg < 22.5) return 'East (→)';
  if (deg >= 22.5 && deg < 67.5) return 'South-East (↘)';
  if (deg >= 67.5 && deg < 112.5) return 'South (↓)';
  if (deg >= 112.5 && deg < 157.5) return 'South-West (↙)';
  if (deg >= 157.5 && deg < 202.5) return 'West (←)';
  if (deg >= 202.5 && deg < 247.5) return 'North-West (↖)';
  if (deg >= 247.5 && deg < 292.5) return 'North (↑)';
  return 'North-East (↗)';
}

export class ZoneAnalyzer {
  private zones: CrowdZone[] = [];
  // Track previous memberships to detect entry and exit events
  private previousZoneOccupants: Map<string, Set<string>> = new Map();
  // History of entry/exit events within sliding 60-second window
  private entryEvents: { zoneId: string; time: number }[] = [];
  private exitEvents: { zoneId: string; time: number }[] = [];

  constructor(initialZones: CrowdZone[] = DEFAULT_ZONES) {
    this.zones = JSON.parse(JSON.stringify(initialZones));
    this.zones.forEach((z) => this.previousZoneOccupants.set(z.id, new Set()));
  }

  public getZones(): CrowdZone[] {
    return this.zones;
  }

  public setZones(newZones: CrowdZone[]): void {
    this.zones = newZones;
    this.zones.forEach((z) => {
      if (!this.previousZoneOccupants.has(z.id)) {
        this.previousZoneOccupants.set(z.id, new Set());
      }
    });
  }

  public update(tracks: TrackedPerson[], now: number = Date.now()): CrowdZone[] {
    // Purge entry/exit events older than 60 seconds
    const windowStart = now - 60000;
    this.entryEvents = this.entryEvents.filter((e) => e.time >= windowStart);
    this.exitEvents = this.exitEvents.filter((e) => e.time >= windowStart);

    // Group tracks into zones
    const currentOccupantsByZone: Map<string, TrackedPerson[]> = new Map();
    this.zones.forEach((z) => currentOccupantsByZone.set(z.id, []));

    for (const track of tracks) {
      let assignedZoneId: string | null = null;
      for (const zone of this.zones) {
        if (isPointInPolygon(track.currentPos, zone.polygon)) {
          assignedZoneId = zone.id;
          currentOccupantsByZone.get(zone.id)?.push(track);
          break;
        }
      }
      track.zoneId = assignedZoneId;
    }

    // Detect entries and exits
    for (const zone of this.zones) {
      const currentIds = new Set(
        (currentOccupantsByZone.get(zone.id) || []).map((t) => t.trackId)
      );
      const prevIds = this.previousZoneOccupants.get(zone.id) || new Set();

      // New entries
      for (const id of currentIds) {
        if (!prevIds.has(id)) {
          this.entryEvents.push({ zoneId: zone.id, time: now });
        }
      }

      // Exits
      for (const id of prevIds) {
        if (!currentIds.has(id)) {
          this.exitEvents.push({ zoneId: zone.id, time: now });
        }
      }

      this.previousZoneOccupants.set(zone.id, currentIds);
    }

    // Compute updated zone metrics
    for (const zone of this.zones) {
      const occupants = currentOccupantsByZone.get(zone.id) || [];
      const count = occupants.length;
      zone.currentCount = count;

      // Area in estimated real-world square meters (calibrated: ~10,000 px² = 15 m²)
      const pixelArea = getPolygonArea(zone.polygon);
      const estimatedM2 = Math.max(5, pixelArea / 600);
      zone.density = Number((count / estimatedM2).toFixed(2));

      // Calculate rates per minute based on the 60s sliding window
      const entries = this.entryEvents.filter((e) => e.zoneId === zone.id).length;
      const exits = this.exitEvents.filter((e) => e.zoneId === zone.id).length;
      zone.entryRate = Math.round(entries * 1.0); // 1-minute window
      zone.exitRate = Math.round(exits * 1.0);
      zone.inflowOutflowBalance = zone.entryRate - zone.exitRate;

      // Average dwell time
      if (count > 0) {
        const totalDwell = occupants.reduce((acc, t) => acc + t.dwellTime, 0);
        zone.avgDwellTime = Number((totalDwell / count).toFixed(1));

        // Average speed & dominant direction
        let sumVx = 0;
        let sumVy = 0;
        let totalSpeed = 0;

        for (const t of occupants) {
          sumVx += t.velocity.x;
          sumVy += t.velocity.y;
          totalSpeed += t.speed;
        }

        zone.avgSpeed = Number((totalSpeed / count).toFixed(1));

        const avgVx = sumVx / count;
        const avgVy = sumVy / count;
        const dominantMag = Math.hypot(avgVx, avgVy);

        if (dominantMag > 1.0) {
          zone.dominantVector = { x: avgVx / dominantMag, y: avgVy / dominantMag };
          const dominantAngle = Math.atan2(avgVy, avgVx);
          zone.dominantDirection = angleToDirectionString(dominantAngle);
        } else {
          zone.dominantVector = { x: 0, y: 0 };
          zone.dominantDirection = 'Stationary / Dispersed';
        }
      } else {
        zone.avgDwellTime = 0;
        zone.avgSpeed = 0;
        zone.dominantDirection = 'Clear';
        zone.dominantVector = { x: 0, y: 0 };
      }
    }

    return this.zones;
  }
}
