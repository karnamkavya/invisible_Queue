import { Point } from '../types';

export class CrowdHeatmap {
  private width: number;
  private height: number;
  private offscreenCanvas: HTMLCanvasElement;
  private offscreenCtx: CanvasRenderingContext2D | null;
  private gradientCanvas: HTMLCanvasElement;
  private gradientCtx: CanvasRenderingContext2D | null;

  constructor(width: number = 640, height: number = 360) {
    this.width = width;
    this.height = height;
    this.offscreenCanvas = document.createElement('canvas');
    this.offscreenCanvas.width = width;
    this.offscreenCanvas.height = height;
    this.offscreenCtx = this.offscreenCanvas.getContext('2d', { willReadFrequently: true });

    // Pre-render 256x1 color palette gradient
    this.gradientCanvas = document.createElement('canvas');
    this.gradientCanvas.width = 256;
    this.gradientCanvas.height = 1;
    this.gradientCtx = this.gradientCanvas.getContext('2d');
    this.initGradient();
  }

  private initGradient(): void {
    if (!this.gradientCtx) return;
    const grad = this.gradientCtx.createLinearGradient(0, 0, 256, 0);
    // Cold to warm spectrum: Transparent -> Blue -> Cyan -> Lime -> Yellow -> Red
    grad.addColorStop(0.0, 'rgba(0, 0, 255, 0)');
    grad.addColorStop(0.2, 'rgba(0, 180, 255, 0.4)');
    grad.addColorStop(0.4, 'rgba(0, 255, 128, 0.7)');
    grad.addColorStop(0.65, 'rgba(255, 230, 0, 0.85)');
    grad.addColorStop(0.85, 'rgba(255, 100, 0, 0.92)');
    grad.addColorStop(1.0, 'rgba(235, 30, 30, 0.98)');

    this.gradientCtx.fillStyle = grad;
    this.gradientCtx.fillRect(0, 0, 256, 1);
  }

  public setDimensions(width: number, height: number): void {
    if (this.width === width && this.height === height) return;
    this.width = width;
    this.height = height;
    this.offscreenCanvas.width = width;
    this.offscreenCanvas.height = height;
  }

  public reset(): void {
    if (!this.offscreenCtx) return;
    this.offscreenCtx.clearRect(0, 0, this.width, this.height);
  }

  /**
   * Adds person positions and applies smooth decay
   */
  public update(points: Point[], decayRate: number = 0.92, radius: number = 28): void {
    if (!this.offscreenCtx) return;

    // 1. Fade previous accumulation (temporal decay)
    this.offscreenCtx.globalCompositeOperation = 'source-over';
    this.offscreenCtx.fillStyle = `rgba(0, 0, 0, ${1 - decayRate})`;
    this.offscreenCtx.fillRect(0, 0, this.width, this.height);

    // 2. Add new point intensities as soft alpha circles
    for (const pt of points) {
      const radGrad = this.offscreenCtx.createRadialGradient(
        pt.x,
        pt.y,
        0,
        pt.x,
        pt.y,
        radius
      );
      radGrad.addColorStop(0, 'rgba(255, 255, 255, 0.35)');
      radGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.15)');
      radGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');

      this.offscreenCtx.fillStyle = radGrad;
      this.offscreenCtx.beginPath();
      this.offscreenCtx.arc(pt.x, pt.y, radius, 0, Math.PI * 2);
      this.offscreenCtx.fill();
    }
  }

  /**
   * Colorizes alpha intensities with heatmap spectrum and draws onto destination context
   */
  public renderTo(
    targetCtx: CanvasRenderingContext2D,
    opacity: number = 0.65,
    destWidth: number = this.width,
    destHeight: number = this.height
  ): void {
    if (!this.offscreenCtx || !this.gradientCtx) return;

    try {
      const srcData = this.offscreenCtx.getImageData(0, 0, this.width, this.height);
      const paletteData = this.gradientCtx.getImageData(0, 0, 256, 1).data;
      const pixels = srcData.data;

      // Colorize based on alpha/brightness
      for (let i = 0; i < pixels.length; i += 4) {
        const alpha = pixels[i]; // luminance from grayscale canvas
        if (alpha > 5) {
          const colorIdx = Math.min(255, alpha) * 4;
          pixels[i] = paletteData[colorIdx]; // R
          pixels[i + 1] = paletteData[colorIdx + 1]; // G
          pixels[i + 2] = paletteData[colorIdx + 2]; // B
          pixels[i + 3] = Math.floor(paletteData[colorIdx + 3] * opacity * (alpha / 255)); // A
        } else {
          pixels[i + 3] = 0;
        }
      }

      this.offscreenCtx.putImageData(srcData, 0, 0);

      // Draw onto target
      targetCtx.save();
      targetCtx.globalAlpha = 1.0;
      targetCtx.drawImage(
        this.offscreenCanvas,
        0,
        0,
        this.width,
        this.height,
        0,
        0,
        destWidth,
        destHeight
      );
      targetCtx.restore();
    } catch {
      // Fallback
    }
  }
}
