import React from 'react';
import { OperationalRecommendation } from '../types';
import { Sparkles, ArrowRight, ShieldCheck, CheckCircle, RefreshCw } from 'lucide-react';

interface RecommendationPanelProps {
  recommendations: OperationalRecommendation[];
  onRefresh: () => void;
  isLoading: boolean;
}

export const RecommendationPanel: React.FC<RecommendationPanelProps> = ({
  recommendations,
  onRefresh,
  isLoading,
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col h-full">
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Operational AI Recommendations
          </h2>
        </div>
        <button
          onClick={onRefresh}
          disabled={isLoading}
          className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
          <span>{isLoading ? 'Synthesizing...' : 'Refresh AI'}</span>
        </button>
      </div>

      {/* AI Suggestion Mandatory Notice (Section 12 & 31) */}
      <div className="bg-cyan-950/60 border border-cyan-800/80 rounded-lg p-2.5 mb-3 flex items-start gap-2 text-xs text-cyan-200">
        <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">AI-generated suggestion:</span> Operational recommendations are generated based on real-time spatial telemetry to support human operators. They are not automated physical override instructions.
        </div>
      </div>

      <div className="flex-1 overflow-y-auto max-h-72 space-y-2.5 pr-1">
        {recommendations.length === 0 ? (
          <div className="p-6 text-center text-slate-500 text-xs">
            Awaiting crowd telemetry signals...
          </div>
        ) : (
          recommendations.map((rec) => {
            let prioBadge = 'bg-slate-800 text-slate-300 border-slate-700';
            if (rec.priority === 'HIGH') {
              prioBadge = 'bg-rose-950 text-rose-300 border-rose-800';
            } else if (rec.priority === 'MEDIUM') {
              prioBadge = 'bg-amber-950 text-amber-300 border-amber-800';
            }

            return (
              <div
                key={rec.id}
                className="bg-slate-800/70 border border-slate-700/70 rounded-lg p-3 hover:border-slate-600 transition-colors"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                    <ArrowRight className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{rec.action}</span>
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border font-bold ${prioBadge}`}>
                    {rec.priority} PRIORITY
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-2">
                  {rec.detail}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-1 text-[11px] bg-slate-900/80 p-2 rounded border border-slate-800">
                  <div className="text-slate-400">
                    Target: <strong className="text-cyan-300">{rec.targetZone}</strong>
                  </div>
                  <div className="text-slate-400">
                    Impact: <strong className="text-emerald-300">{rec.expectedImpact}</strong>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
