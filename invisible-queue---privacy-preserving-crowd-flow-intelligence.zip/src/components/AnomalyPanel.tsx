import React from 'react';
import { AnomalyEvent } from '../types';
import { AlertCircle, Clock, MapPin, Zap, RefreshCw } from 'lucide-react';

interface AnomalyPanelProps {
  anomalies: AnomalyEvent[];
  onClear: () => void;
}

export const AnomalyPanel: React.FC<AnomalyPanelProps> = ({ anomalies, onClear }) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col h-full">
      <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200">
            Anomaly Detection Stream
          </h2>
        </div>
        {anomalies.length > 0 && (
          <button
            onClick={onClear}
            className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Clear</span>
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto max-h-72 space-y-2 pr-1">
        {anomalies.length === 0 ? (
          <div className="p-6 text-center text-slate-500 text-xs flex flex-col items-center justify-center">
            <AlertCircle className="w-6 h-6 text-slate-600 mb-1.5" />
            <span>No unusual movement patterns currently detected.</span>
            <span className="text-[10px] text-slate-600 mt-0.5">
              Continuously screening velocity vectors, density deltas, and directional conflicts.
            </span>
          </div>
        ) : (
          anomalies.map((anom) => {
            const timeStr = new Date(anom.timestamp).toLocaleTimeString();
            return (
              <div
                key={anom.id}
                className="bg-slate-800/70 border border-amber-900/60 rounded-lg p-2.5 hover:border-amber-700/80 transition-colors"
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                    {anom.patternType}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-900/80 px-1.5 py-0.5 rounded">
                    {Math.round(anom.confidence * 100)}% conf
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-snug mb-1.5">
                  {anom.description}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-700/50">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-cyan-400" />
                    <span>{anom.zoneName}</span>
                  </span>
                  <span className="flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{timeStr}</span>
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="text-[10px] text-slate-500 italic mt-2 border-t border-slate-800 pt-1.5">
        Standard wording: "Unusual movement pattern detected" (avoids alarmist false assumptions).
      </div>
    </div>
  );
};
